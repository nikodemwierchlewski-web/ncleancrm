package pl.nclean.crm.calendar;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import pl.nclean.crm.dashboard.DashboardService;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import org.flywaydb.core.Flyway;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import pl.nclean.crm.CrmApplication;

import static org.junit.jupiter.api.Assertions.*;

/** Actual HTTP, Security, Flyway, Hibernate and PostgreSQL; never an external datasource. */
@Testcontainers
class CalendarPostgresIT {
    @Container
    static final PostgreSQLContainer<?> POSTGRES = new PostgreSQLContainer<>(DockerImageName.parse(
        "postgres@sha256:31ba9c94a03ada9988f2bb493a22a75eef3a185884533e5cdbcd498ea835b08f"))
        .withDatabaseName("calendar_integration")
        .withUsername("calendar_test")
        .withPassword(UUID.randomUUID().toString());

    private static final String OWNER = "integration-owner";
    private static final String PASSWORD = UUID.randomUUID().toString();
    private static final String PASSWORD_HASH = new BCryptPasswordEncoder(12).encode(PASSWORD);
    private static final String DAY = "2026-10-28";
    private RunningApp app;
    private JdbcTemplate jdbc;

    private static final List<String> SEED_NAMES = List.of("Fabryczna", "Krzyki", "Psie Pole", "Stare Miasto", "Śródmieście");
    private static final List<String> SEED_COLORS = List.of("#DBEAFE", "#D1FAE5", "#FEF3C7", "#FCE7F3", "#EDE9FE");

    @BeforeEach
    void startIsolatedApplication() {
        app = RunningApp.start();
        jdbc = app.context().getBean(JdbcTemplate.class);
        jdbc.update("DELETE FROM removal_audit");jdbc.update("UPDATE service_category SET removed_at=NULL");jdbc.update("UPDATE service_definition SET removed_at=NULL");
        jdbc.update("DELETE FROM tycoon_award");jdbc.update("DELETE FROM cost_audit");jdbc.update("DELETE FROM cost_entry");jdbc.update("DELETE FROM equipment_item");jdbc.update("DELETE FROM memo_step");jdbc.update("DELETE FROM memo_entry");jdbc.update("DELETE FROM day_review");jdbc.update("DELETE FROM booking_move");jdbc.update("DELETE FROM booking_photo");jdbc.update("DELETE FROM customer_contact");
        jdbc.update("DELETE FROM booking_payment");jdbc.update("DELETE FROM booking_audit");
        jdbc.update("DELETE FROM fuel_audit");jdbc.update("DELETE FROM fuel_purchase");jdbc.update("DELETE FROM fuel_receipt");jdbc.update("DELETE FROM fuel_day");jdbc.update("DELETE FROM fuel_parameters");
        jdbc.update("DELETE FROM dashboard_month_cost");jdbc.update("DELETE FROM dashboard_month");jdbc.update("DELETE FROM dashboard_fuel");
        jdbc.update("DELETE FROM booking_actual_chemical");jdbc.update("DELETE FROM booking_chemical");jdbc.update("DELETE FROM booking_item");jdbc.update("DELETE FROM booking");jdbc.update("DELETE FROM crm_customer");
        jdbc.update("DELETE FROM service_chemical");jdbc.update("UPDATE service_definition SET chemistry_defined=FALSE");jdbc.update("DELETE FROM chemical");
        jdbc.update("DELETE FROM weekly_area");jdbc.update("DELETE FROM weekly_area_plan");jdbc.update("DELETE FROM day_area_override");
        jdbc.update("DELETE FROM day_district");
        jdbc.update("DELETE FROM district WHERE id > 5");
        for (int i = 0; i < SEED_NAMES.size(); i++) {
            jdbc.update("UPDATE district SET name = ?, color = ?, active = TRUE WHERE id = ?", SEED_NAMES.get(i), SEED_COLORS.get(i), i + 1);
        }
    }

    @AfterEach
    void stopApplication() {
        if (app != null) app.close();
    }

    @Test
    void flywayCreatesLatestSchemaAndFiveOperationalAreas() {
        assertEquals(List.of("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"), jdbc.queryForList(
            "SELECT version FROM flyway_schema_history WHERE success = TRUE AND type = 'SQL' ORDER BY installed_rank", String.class));
        assertEquals(SEED_NAMES, jdbc.queryForList("SELECT name FROM district ORDER BY id", String.class));
        assertEquals(5, jdbc.queryForObject("SELECT count(*) FROM district WHERE active = TRUE", Integer.class));
        assertEquals(List.of("day", "district_id"), jdbc.queryForList(
            "SELECT column_name FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'day_district' ORDER BY ordinal_position", String.class));
        assertTrue(jdbc.queryForObject("SELECT bool_and(color ~ '^#[0-9A-Fa-f]{6}$') FROM district", Boolean.class));
    }

    @Test
    void upgradingV1PreservesExistingAssignmentAndAllowsSecondAreaOnSameDay() {
        String schema = "legacy_upgrade";
        String schemaUrl = POSTGRES.getJdbcUrl() + (POSTGRES.getJdbcUrl().contains("?") ? "&" : "?") + "currentSchema=" + schema;
        var source = new DriverManagerDataSource(schemaUrl, POSTGRES.getUsername(), POSTGRES.getPassword());
        var legacy = new JdbcTemplate(source);
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).target("1").load().migrate();
        long first = legacy.queryForObject("SELECT id FROM district WHERE name = 'Fabryczna'", Long.class);
        long second = legacy.queryForObject("SELECT id FROM district WHERE name = 'Krzyki'", Long.class);
        legacy.update("INSERT INTO day_district(day, district_id) VALUES (?, ?)", java.sql.Date.valueOf(DAY), first);

        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).load().migrate();
        assertEquals(List.of(first), legacy.queryForList("SELECT district_id FROM day_district WHERE day = DATE '2026-10-28'", Long.class));
        legacy.update("INSERT INTO day_district(day, district_id) VALUES (?, ?)", java.sql.Date.valueOf(DAY), second);
        assertEquals(List.of(first, second), legacy.queryForList("SELECT district_id FROM day_district WHERE day = DATE '2026-10-28' ORDER BY district_id", Long.class));
        assertEquals(5, legacy.queryForObject("SELECT count(*) FROM district", Integer.class));
        assertEquals(List.of("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"), legacy.queryForList("SELECT version FROM flyway_schema_history WHERE success = TRUE AND type = 'SQL' ORDER BY installed_rank", String.class));
    }

    @Test
    void ownerLogsInAndReadsMonthAndSelectedDayFromRealDatabase() throws Exception {
        var browser = app.browser();
        var protectedPage = browser.get("/calendar?month=2026-10");
        assertEquals(302, protectedPage.statusCode());
        assertTrue(protectedPage.headers().firstValue("Location").orElseThrow().endsWith("/login"));
        browser.login();
        var month = browser.get("/calendar?month=2026-10");
        assertEquals(200, month.statusCode());
        assertTrue(month.body().contains("2026-10-28"));
        var selected = browser.get(calendarPath(DAY));
        assertEquals(200, selected.statusCode());
        assertTrue(selected.body().contains("Krzyki"));
        assertTrue(selected.body().contains("districtIds"));
        assertTrue(selected.body().contains("name=\"_csrf\""));
    }

    @Test
    void ownerAssignsSeveralAreasDeduplicatesReplacesAndClears() throws Exception {
        var browser = app.browser(); browser.login();
        long first = areaId("Fabryczna"), second = areaId("Krzyki"), third = areaId("Psie Pole");
        assertCalendarRedirect(browser.assign(DAY, List.of(first, second, first), true), DAY);
        assertEquals(List.of(first, second), assignedAreas(DAY));
        var rendered = browser.get(calendarPath(DAY)).body();
        assertTrue(rendered.contains("Fabryczna") && rendered.contains("Krzyki"));
        assertCalendarRedirect(browser.assign(DAY, List.of(second, third), true), DAY);
        assertEquals(List.of(second, third), assignedAreas(DAY));
        assertCalendarRedirect(browser.assign(DAY, List.of(), true), DAY);
        assertEquals(List.of(), assignedAreas(DAY));
    }

    @Test
    void invalidUnauthorizedAndCsrfFreeWritesPreserveExistingAreas() throws Exception {
        long first = areaId("Fabryczna"), inactive = areaId("Krzyki");
        var browser = app.browser();
        assertEquals(403, browser.post("/calendar/areas", Map.of("date", DAY, "districtIds", first)).statusCode());
        browser.login();
        assertCalendarRedirect(browser.assign(DAY, List.of(first), true), DAY);
        assertEquals(403, browser.assign(DAY, List.of(inactive), false).statusCode());
        assertHtmlBadRequest(browser.assign(DAY, List.of(first, Long.MAX_VALUE), true));
        jdbc.update("UPDATE district SET active = FALSE WHERE id = ?", inactive);
        assertHtmlBadRequest(browser.assign(DAY, List.of(first, inactive), true));
        for (String invalidDate : List.of("1999-12-31", "2101-01-01", "not-a-date")) {
            assertHtmlBadRequest(browser.assign(invalidDate, List.of(first), true));
        }
        for (String invalidMonth : List.of("1999-12", "2101-01", "not-a-month")) {
            assertEquals(400, browser.get("/calendar?month=" + invalidMonth).statusCode());
        }
        assertEquals(400, browser.get("/calendar?month=2026-10&day=2101-01-01").statusCode());
        assertEquals(List.of(first), assignedAreas(DAY));
        assertEquals(1, jdbc.queryForObject("SELECT count(*) FROM day_district", Integer.class));
    }

    @Test
    void settingsCreateRenameRecolorAndDeactivateWithoutLosingAssignments() throws Exception {
        var browser = app.browser(); browser.login();
        assertSettingsRedirect(browser.settings("/settings/areas", Map.of("name", "Strefa testowa", "color", "#1A2B3C"), true));
        long created = areaId("Strefa testowa"), first = areaId("Fabryczna");
        assertCalendarRedirect(browser.assign(DAY, List.of(first, created), true), DAY);
        assertSettingsRedirect(browser.settings("/settings/areas/" + created, Map.of("name", "Osiedle testowe", "color", "#5E6F70"), true));
        assertEquals("#5E6F70", jdbc.queryForObject("SELECT color FROM district WHERE id = ?", String.class, created));
        assertSettingsRedirect(browser.settings("/settings/areas/" + created + "/active", Map.of("active", "false"), true));
        assertFalse(jdbc.queryForObject("SELECT active FROM district WHERE id = ?", Boolean.class, created));
        assertEquals(List.of(first, created), assignedAreas(DAY));
        var rendered = browser.get(calendarPath(DAY)).body();
        assertTrue(rendered.contains("Osiedle testowe"));
        assertTrue(rendered.contains("#5E6F70"));
        assertTrue(rendered.toLowerCase(java.util.Locale.ROOT).contains("nieaktywn"));
        // Retaining a historical inactive area is allowed; assigning it to another day is not.
        assertCalendarRedirect(browser.assign(DAY, List.of(first, created), true), DAY);
        assertHtmlBadRequest(browser.assign("2026-10-29", List.of(created), true));
        assertEquals(List.of(), assignedAreas("2026-10-29"));
        assertCalendarRedirect(browser.assign(DAY, List.of(), true), DAY);
        assertHtmlBadRequest(browser.assign(DAY, List.of(created), true));
        assertSettingsRedirect(browser.settings("/settings/areas/" + created + "/active", Map.of("active", "true"), true));
        assertCalendarRedirect(browser.assign(DAY, List.of(created), true), DAY);
    }

    @Test
    void settingsRejectInvalidNamesColorsDuplicatesUnknownIdsAndMissingCsrf() throws Exception {
        var browser = app.browser(); browser.login();
        assertEquals(403, browser.settings("/settings/areas", Map.of("name", "Nowa strefa", "color", "#123456"), false).statusCode());
        for (var invalid : List.of(
                Map.of("name", " ", "color", "#123456"),
                Map.of("name", "A".repeat(101), "color", "#123456"),
                Map.of("name", "Nowa strefa", "color", "red"),
                Map.of("name", "Nowa strefa", "color", "#123"),
                Map.of("name", "Nowa strefa", "color", "#1234567"),
                Map.of("name", "Nowa strefa", "color", "#GGGGGG"),
                Map.of("name", "fabryczna", "color", "#123456"))) {
            assertHtmlBadRequest(browser.settings("/settings/areas", invalid, true));
        }
        assertHtmlBadRequest(browser.settings("/settings/areas/" + areaId("Krzyki"), Map.of("name", "FABRYCZNA", "color", "#123456"), true));
        assertEquals(404, browser.get("/settings/areas?edit=" + Long.MAX_VALUE).statusCode());
        assertEquals(404, browser.settings("/settings/areas/" + Long.MAX_VALUE, Map.of("name", "Nowa strefa", "color", "#123456"), true).statusCode());
        assertEquals(404, browser.settings("/settings/areas/" + Long.MAX_VALUE + "/active", Map.of("active", "false"), true).statusCode());
        assertEquals(5, jdbc.queryForObject("SELECT count(*) FROM district", Integer.class));
        assertEquals(SEED_NAMES, jdbc.queryForList("SELECT name FROM district ORDER BY id", String.class));
    }

    @Test
    void severalAreasWithEditedNameColorAndInactiveHistorySurviveApplicationRestart() throws Exception {
        var browser = app.browser(); browser.login();
        assertSettingsRedirect(browser.settings("/settings/areas", Map.of("name", "Przed zmianą", "color", "#123456"), true));
        long created = areaId("Przed zmianą"), first = areaId("Fabryczna");
        assertCalendarRedirect(browser.assign(DAY, List.of(first, created), true), DAY);
        assertSettingsRedirect(browser.settings("/settings/areas/" + created, Map.of("name", "Po zmianie", "color", "#654321"), true));
        assertSettingsRedirect(browser.settings("/settings/areas/" + created + "/active", Map.of("active", "false"), true));
        var previousContext = app.context(); app.close(); assertFalse(previousContext.isActive());
        app = RunningApp.start(); jdbc = app.context().getBean(JdbcTemplate.class);
        assertEquals(List.of(first, created), assignedAreas(DAY));
        assertEquals("Po zmianie", jdbc.queryForObject("SELECT name FROM district WHERE id = ?", String.class, created));
        assertEquals("#654321", jdbc.queryForObject("SELECT color FROM district WHERE id = ?", String.class, created));
        assertFalse(jdbc.queryForObject("SELECT active FROM district WHERE id = ?", Boolean.class, created));
        var newSession = app.browser(); assertEquals(302, newSession.get(calendarPath(DAY)).statusCode()); newSession.login();
        var page = newSession.get(calendarPath(DAY)); assertEquals(200, page.statusCode());
        assertTrue(page.body().contains("Po zmianie") && page.body().contains("#654321"));
        assertEquals(16, jdbc.queryForObject("SELECT count(*) FROM flyway_schema_history WHERE success = TRUE AND type = 'SQL'", Integer.class));
    }

    @Test
    void customerCatalogueAndBookingKeepHistoricalPricesAfterRestart() throws Exception {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        var browser=app.browser();browser.login();
        assertEquals(200,browser.get("/customers").statusCode());
        assertEquals(200,browser.get("/settings/services").statusCode());
        long person=records.saveCustomer(null,0,"Klient syntetyczny","500000010","Adres przykładowy 1","Notatka",true);
        assertEquals("+48500000010",jdbc.queryForObject("SELECT phone FROM crm_customer WHERE id=?",String.class,person));
        var service=records.services().get(0);long serviceId=((Number)service.get("id")).longValue();
        var price=(java.math.BigDecimal)service.get("price");String token=UUID.randomUUID().toString();
        var fields=new LinkedHashMap<String,Object>();fields.put("token",token);fields.put("day",DAY);fields.put("starts","09:00");fields.put("customer",person);fields.put("address","Adres realizacji 2");fields.put("qty_"+serviceId,"2");
        assertEquals(302,browser.settings("/orders",fields,true).statusCode());
        assertEquals(302,browser.settings("/orders",fields,true).statusCode());
        long booking=jdbc.queryForObject("SELECT id FROM booking WHERE request_token=?::uuid",Long.class,token);
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM booking WHERE request_token=?::uuid",Integer.class,token));
        assertEquals(200,browser.get("/orders?day="+DAY).statusCode());
        assertEquals(302,browser.settings("/settings/services",Map.of("id",serviceId,"version",service.get("version"),"category",service.get("category_id"),"name","Usługa po zmianie","unit","pakiet","price",price.add(new java.math.BigDecimal("50.00")).toPlainString(),"minutes","60","active","on"),true).statusCode());
        records.saveCustomer(person,0,"Nowa nazwa klienta","500000011","Inny adres","",true);
        assertEquals(302,browser.settings("/orders/"+booking,Map.of("version","0","day","2026-10-29","starts","10:00","status","DONE"),true).statusCode());
        assertEquals(0,price.multiply(java.math.BigDecimal.valueOf(2)).compareTo(jdbc.queryForObject("SELECT total FROM booking WHERE id=?",java.math.BigDecimal.class,booking)));
        assertEquals("Klient syntetyczny",jdbc.queryForObject("SELECT customer_name FROM booking WHERE id=?",String.class,booking));
        assertEquals(service.get("name"),jdbc.queryForObject("SELECT name FROM booking_item WHERE booking_id=?",String.class,booking));
        long count=jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class);
        assertThrows(IllegalArgumentException.class,()->records.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Nie zapisuj","500000010","Adres",Map.of(Long.MAX_VALUE,java.math.BigDecimal.ONE)));
        assertEquals(count,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class));
        assertThrows(IllegalArgumentException.class,()->records.saveCustomer(person,0,"Nie nadpisuj","500000010","","",true));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        assertEquals("DONE",jdbc.queryForObject("SELECT status FROM booking WHERE id=?",String.class,booking));
        var after=app.browser();after.login();assertEquals(200,after.get("/orders").statusCode());
    }

    @Test
    void failedBookingRollsBackInlineCustomerAndFormsRejectMissingData() throws Exception {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        long category=((Number)records.categories().get(0).get("id")).longValue();
        records.service(null,0,category,"Próba rollback","szt.","9999999999.99",1,true);
        long service=jdbc.queryForObject("SELECT id FROM service_definition WHERE name='Próba rollback'",Long.class);
        long before=jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class);
        assertThrows(org.springframework.dao.DataIntegrityViolationException.class,()->records.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Wycofaj","500000010","Adres",Map.of(service,new java.math.BigDecimal("10000"))));
        assertEquals(before,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class));
        var browser=app.browser();browser.login();
        assertHtmlBadRequest(browser.settings("/orders",Map.of("day",DAY,"starts","09:00"),true));
        assertHtmlBadRequest(browser.settings("/customers",Map.of("name","Brak numeru"),true));
        assertHtmlBadRequest(browser.settings("/settings/services",Map.of("name","Brak danych"),true));
        records.category(null,"Nowa kategoria");
        long created=jdbc.queryForObject("SELECT id FROM service_category WHERE name='Nowa kategoria'",Long.class);
        records.category(created,"Kategoria zmieniona");
        records.service(service,0,created,"Usługa wyłączona","m²","12.50",20,false);
        assertThrows(IllegalArgumentException.class,()->records.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Nie dodawaj","500000010","Adres",Map.of(service,java.math.BigDecimal.ONE)));
        assertEquals(before,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class));
    }

    private long areaId(String name) { return jdbc.queryForObject("SELECT id FROM district WHERE name = ?", Long.class, name); }
    private List<Long> assignedAreas(String day) {
        return jdbc.queryForList("SELECT district_id FROM day_district WHERE day = ? ORDER BY district_id", Long.class, java.sql.Date.valueOf(day));
    }
    private static String calendarPath(String day) { return "/calendar?month=2026-10&day=" + day; }
    @Test
    void calendarShowsEightBookingsInTimeOrderAndJsonWritesSurviveRestart() throws Exception {
        jdbc.update("DELETE FROM booking_item");jdbc.update("DELETE FROM booking");jdbc.update("DELETE FROM crm_customer");
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        var browser=app.browser();browser.login();
        long person=data.saveCustomer(null,0,"Klient kalendarza","500000020","Adres domyślny","",true);
        long service=((Number)data.services().get(0).get("id")).longValue();
        for(int hour=15;hour>=8;hour--)data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.of(hour,0),person,null,null,"Adres wizyty",Map.of(service,java.math.BigDecimal.ONE));
        var month=data.monthBookings(java.time.YearMonth.of(2026,10));assertEquals(8,month.size());
        assertEquals("08:00:00",month.get(0).get("starts").toString());
        var page=browser.get(calendarPath(DAY));assertEquals(200,page.statusCode());assertTrue(page.body().contains("+6 kolejnych"));
        String token=UUID.randomUUID().toString();
        var fields=Map.<String,Object>of("calendar","1","token",token,"day",DAY,"starts","16:00","customer",person,"name","Kontakt na tę wizytę","phone","500000021","address","Inny adres","qty_"+service,"1");
        assertEquals(403,browser.settings("/orders",fields,false).statusCode());
        var created=browser.settings("/orders",fields,true);assertEquals(200,created.statusCode());assertTrue(created.body().contains("saved"));
        assertEquals(200,browser.settings("/orders",fields,true).statusCode());
        assertEquals(9,jdbc.queryForObject("SELECT count(*) FROM booking",Integer.class));
        assertEquals("Klient kalendarza",jdbc.queryForObject("SELECT name FROM crm_customer WHERE id=?",String.class,person));
        long id=jdbc.queryForObject("SELECT id FROM booking WHERE request_token=?::uuid",Long.class,token);
        assertEquals("Kontakt na tę wizytę",jdbc.queryForObject("SELECT customer_name FROM booking WHERE id=?",String.class,id));
        var invalid=new LinkedHashMap<String,Object>(fields);invalid.put("token",UUID.randomUUID());invalid.put("qty_"+service,"-1");
        var rejected=browser.settings("/orders",invalid,true);assertEquals(400,rejected.statusCode());assertTrue(rejected.headers().firstValue("Content-Type").orElse("").contains("application/json"));
        assertEquals(200,browser.settings("/calendar/areas",Map.of("calendar","1","date",DAY,"districtIds",List.of(areaId("Krzyki"),areaId("Fabryczna"))),true).statusCode());
        assertEquals(200,browser.settings("/orders/"+id,Map.of("calendar","1","version","0","day",DAY,"starts","07:30","status","DONE"),true).statusCode());
        assertEquals(400,browser.settings("/orders/"+id,Map.of("calendar","1","version","0","day",DAY,"starts","07:30","status","DONE"),true).statusCode());
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        var after=app.browser();after.login();var html=after.get(calendarPath(DAY));assertEquals(200,html.statusCode());assertTrue(html.body().contains("Kontakt na tę wizytę"));
        assertEquals(2,assignedAreas(DAY).size());assertEquals("DONE",jdbc.queryForObject("SELECT status FROM booking WHERE id=?",String.class,id));
    }

    @Test
    void bookingAcrossCategoriesKeepsEveryItemAndVisitContactAfterRestart() throws Exception {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        var active=data.services().stream().filter(s -> Boolean.TRUE.equals(s.get("active"))).toList();
        var first=active.get(0);
        var second=active.stream().filter(s -> !s.get("category_id").equals(first.get("category_id"))).findFirst().orElseThrow();
        long firstId=((Number)first.get("id")).longValue(),secondId=((Number)second.get("id")).longValue();
        long customer=data.saveCustomer(null,0,"Stały klient lean","500000041","Adres domyślny lean","",true);
        var token=UUID.randomUUID();
        var fields=new LinkedHashMap<String,Object>();
        fields.put("calendar","1");fields.put("token",token);fields.put("day","2026-10-30");fields.put("starts","12:30");fields.put("customer",customer);
        fields.put("name","Kontakt wizyty lean");fields.put("phone","500000042");fields.put("address","Adres tej wizyty lean");
        fields.put("qty_"+firstId,"2");fields.put("qty_"+secondId,"1.5");
        var browser=app.browser();browser.login();
        assertEquals(403,browser.settings("/orders",fields,false).statusCode());
        assertEquals(200,browser.settings("/orders",fields,true).statusCode());
        assertEquals(200,browser.settings("/orders",fields,true).statusCode());
        long id=jdbc.queryForObject("SELECT id FROM booking WHERE request_token=?",Long.class,token);
        assertEquals(2,data.items(id).size());
        var expected=((java.math.BigDecimal)first.get("price")).multiply(new java.math.BigDecimal("2")).add(((java.math.BigDecimal)second.get("price")).multiply(new java.math.BigDecimal("1.5"))).setScale(2,java.math.RoundingMode.HALF_UP);
        assertEquals(0,expected.compareTo(jdbc.queryForObject("SELECT total FROM booking WHERE id=?",java.math.BigDecimal.class,id)));
        assertEquals("Adres domyślny lean",jdbc.queryForObject("SELECT address FROM crm_customer WHERE id=?",String.class,customer));
        assertEquals("Stały klient lean",jdbc.queryForObject("SELECT name FROM crm_customer WHERE id=?",String.class,customer));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        assertEquals(2,jdbc.queryForObject("SELECT count(*) FROM booking_item WHERE booking_id=?",Integer.class,id));
        assertEquals("Kontakt wizyty lean",jdbc.queryForObject("SELECT customer_name FROM booking WHERE id=?",String.class,id));
        assertEquals("Adres tej wizyty lean",jdbc.queryForObject("SELECT address FROM booking WHERE id=?",String.class,id));
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM booking WHERE request_token=?",Integer.class,token));
    }

    @Test
    void upgradingV3KeepsOldPricesAndDoesNotInventChemicalForecasts() {
        String schema="legacy_estimates",url=POSTGRES.getJdbcUrl()+(POSTGRES.getJdbcUrl().contains("?")?"&":"?")+"currentSchema="+schema;
        var source=new DriverManagerDataSource(url,POSTGRES.getUsername(),POSTGRES.getPassword());var old=new JdbcTemplate(source);
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).target("3").load().migrate();
        long person=old.queryForObject("INSERT INTO crm_customer(name,phone) VALUES ('Stary klient syntetyczny','+48500000088') RETURNING id",Long.class);
        long service=old.queryForObject("SELECT id FROM service_definition WHERE name='Kanapa / sofa'",Long.class);
        long booking=old.queryForObject("INSERT INTO booking(request_token,customer_id,day,starts,customer_name,phone,address,total) VALUES (?,?,DATE '2026-10-28',TIME '10:00','Stary klient syntetyczny','+48500000088','Adres',180) RETURNING id",Long.class,UUID.randomUUID(),person);
        old.update("INSERT INTO booking_item(booking_id,position,service_id,name,unit,quantity,price,amount) VALUES (?,0,?,'Kanapa / sofa','szt.',1,180,180)",booking,service);
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).load().migrate();
        var item=old.queryForMap("SELECT * FROM booking_item WHERE booking_id=?",booking);
        assertEquals(0,new java.math.BigDecimal("180").compareTo((java.math.BigDecimal)item.get("price")));
        assertEquals(0,new java.math.BigDecimal("180").compareTo((java.math.BigDecimal)item.get("suggested_price")));
        assertEquals(false,item.get("forecast_defined"));assertNull(item.get("chemical_cost"));
        assertEquals(0,old.queryForObject("SELECT count(*) FROM booking_chemical",Integer.class));
    }

    @Test
    void weeklyVersionsExceptionsAndRestorePreserveHistoryAndRestart() throws Exception {
        var calendar=app.context().getBean(CalendarService.class);
        var today=java.time.LocalDate.now(java.time.ZoneId.of("Europe/Warsaw"));
        var monday=today.with(java.time.temporal.TemporalAdjusters.nextOrSame(java.time.DayOfWeek.MONDAY));
        long krzyki=areaId("Krzyki"),fabryczna=areaId("Fabryczna");
        calendar.assign(today.minusDays(1),List.of(fabryczna));
        calendar.saveWeekly(today,Map.of(1,List.of(krzyki),2,List.of(fabryczna)));
        assertEquals(java.util.Set.of(krzyki),calendar.assignedAreaIds(monday));
        assertEquals(java.util.Set.of(fabryczna),calendar.assignedAreaIds(monday.plusDays(1)));
        calendar.assign(monday,List.of());assertEquals(java.util.Set.of(),calendar.assignedAreaIds(monday));
        assertTrue(calendar.days(java.time.YearMonth.from(monday)).stream().filter(d->d.date().equals(monday)).findFirst().orElseThrow().overridden());
        calendar.restoreWeekly(monday);assertEquals(java.util.Set.of(krzyki),calendar.assignedAreaIds(monday));
        calendar.assign(monday,List.of(fabryczna));
        calendar.saveWeekly(monday.plusWeeks(1),Map.of(1,List.of(fabryczna)));
        assertEquals(java.util.Set.of(fabryczna),calendar.assignedAreaIds(monday.plusWeeks(1)));
        assertEquals(java.util.Set.of(fabryczna),calendar.assignedAreaIds(monday));
        calendar.restoreWeekly(monday);assertEquals(java.util.Set.of(krzyki),calendar.assignedAreaIds(monday));
        assertEquals(java.util.Set.of(fabryczna),calendar.assignedAreaIds(today.minusDays(1)));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        var after=app.context().getBean(CalendarService.class);assertEquals(java.util.Set.of(krzyki),after.assignedAreaIds(monday));assertEquals(java.util.Set.of(fabryczna),after.assignedAreaIds(monday.plusWeeks(1)));
        var browser=app.browser();browser.login();assertTrue(browser.get("/calendar?day="+monday).body().contains("Z planu tygodniowego"));
    }

    @Test
    void emptyWeeklyPlanReplacesEarlierVersionWithoutChangingEarlierDays() {
        var calendar=app.context().getBean(CalendarService.class);var today=java.time.LocalDate.now(java.time.ZoneId.of("Europe/Warsaw"));
        long krzyki=areaId("Krzyki");var monday=today.with(java.time.temporal.TemporalAdjusters.nextOrSame(java.time.DayOfWeek.MONDAY));
        calendar.saveWeekly(today,Map.of(1,List.of(krzyki)));calendar.saveWeekly(monday.plusWeeks(1),Map.of());
        assertEquals(java.util.Set.of(krzyki),calendar.assignedAreaIds(monday));assertEquals(java.util.Set.of(),calendar.assignedAreaIds(monday.plusWeeks(1)));
        assertThrows(IllegalArgumentException.class,()->calendar.saveWeekly(today.minusDays(1),Map.of(1,List.of(krzyki))));
        calendar.assign(monday,List.of(krzyki));calendar.setAreaActive(krzyki,false);calendar.assign(monday,List.of(krzyki));
        assertEquals(java.util.Set.of(krzyki),calendar.assignedAreaIds(monday));
        assertThrows(IllegalArgumentException.class,()->calendar.saveWeekly(monday.plusWeeks(2),Map.of(3,List.of(krzyki))));
    }

    private long estimateService(String name) {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long category=((Number)data.categories().get(0).get("id")).longValue();
        data.service(null,0,category,name,"szt.","180.00",60,true);
        return jdbc.queryForObject("SELECT id FROM service_definition WHERE name=?",Long.class,name);
    }

    @Test
    void negotiatedPriceAndChemicalSnapshotsRemainAfterCatalogueEditsAndRestart() throws Exception {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);
        long service=estimateService("Usługa prognozy");long material=chemistry.saveMaterial(null,0,"Płukanka próba","l","1","50.00");
        chemistry.saveRecipe(service,0,true,Map.of(material,new java.math.BigDecimal("50")));
        var quote=chemistry.quote(service,new java.math.BigDecimal("2"),null);assertEquals(0,new java.math.BigDecimal("5.00").compareTo(quote.cost()));
        var browser=app.browser();browser.login();var token=UUID.randomUUID();
        var fields=Map.<String,Object>of("calendar","1","token",token,"day",DAY,"starts","11:00","name","Klient prognozy","phone","500000070","address","Adres prognozy","qty_"+service,"2","price_"+service,"220.00");
        assertEquals(200,browser.settings("/orders",fields,true).statusCode());assertEquals(200,browser.settings("/orders",fields,true).statusCode());
        long booking=jdbc.queryForObject("SELECT id FROM booking WHERE request_token=?",Long.class,token);
        var item=data.items(booking).get(0);assertEquals(0,new java.math.BigDecimal("180").compareTo((java.math.BigDecimal)item.get("suggested_price")));assertEquals(0,new java.math.BigDecimal("220").compareTo((java.math.BigDecimal)item.get("price")));
        assertEquals(0,new java.math.BigDecimal("440").compareTo(jdbc.queryForObject("SELECT total FROM booking WHERE id=?",java.math.BigDecimal.class,booking)));
        assertEquals(0,new java.math.BigDecimal("5").compareTo(jdbc.queryForObject("SELECT chemical_cost FROM booking WHERE id=?",java.math.BigDecimal.class,booking)));
        chemistry.saveMaterial(material,0,"Płukanka nowa cena","ml","1000","100.00");chemistry.saveRecipe(service,1,true,Map.of(material,new java.math.BigDecimal("150")));
        var current=data.services().stream().filter(v->((Number)v.get("id")).longValue()==service).findFirst().orElseThrow();data.service(service,((Number)current.get("version")).longValue(),((Number)current.get("category_id")).longValue(),"Usługa nowa cena","szt.","300",60,true);
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        var snapshot=jdbc.queryForMap("SELECT * FROM booking_chemical WHERE booking_id=?",booking);assertEquals("Płukanka próba",snapshot.get("name"));assertEquals("ml",snapshot.get("unit"));assertEquals(0,new java.math.BigDecimal("100").compareTo((java.math.BigDecimal)snapshot.get("quantity")));assertEquals(0,new java.math.BigDecimal("5").compareTo((java.math.BigDecimal)snapshot.get("amount")));
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM booking WHERE request_token=?",Integer.class,token));
    }

    @Test
    void manualChemicalForecastZeroUnknownAndDimensionValidationAreDistinct() {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);
        long service=estimateService("Usługa ręcznej prognozy");long liquid=chemistry.saveMaterial(null,0,"Płyn","l","1","50");long powder=chemistry.saveMaterial(null,0,"Proszek","kg","2","80");
        chemistry.saveRecipe(service,0,true,Map.of(liquid,new java.math.BigDecimal("50")));
        assertEquals(0,new java.math.BigDecimal("0.04").compareTo(chemistry.materials().stream().filter(m->m.id()==powder).findFirst().orElseThrow().unitCost()));
        var forecast=new pl.nclean.crm.records.ChemistryService.Forecast(true,Map.of(liquid,new java.math.BigDecimal("20"),powder,new java.math.BigDecimal("10")));
        long booking=data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Ręczna prognoza","500000071","Adres",Map.of(service,new java.math.BigDecimal("2")),Map.of(),Map.of(service,forecast));
        assertEquals(2,data.chemicals(booking).size());assertEquals(0,new java.math.BigDecimal("1.40").compareTo(jdbc.queryForObject("SELECT chemical_cost FROM booking WHERE id=?",java.math.BigDecimal.class,booking)));
        var zero=chemistry.quote(service,java.math.BigDecimal.ONE,new pl.nclean.crm.records.ChemistryService.Forecast(true,Map.of()));assertTrue(zero.defined());assertEquals(0,zero.cost().signum());
        long zeroBooking=data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Prognoza zero","500000079","Adres",Map.of(service,java.math.BigDecimal.ONE),Map.of(),Map.of(service,new pl.nclean.crm.records.ChemistryService.Forecast(true,Map.of())));
        assertTrue((Boolean)data.items(zeroBooking).get(0).get("forecast_defined"));assertEquals(0,jdbc.queryForObject("SELECT chemical_cost FROM booking WHERE id=?",java.math.BigDecimal.class,zeroBooking).signum());
        var unknown=chemistry.quote(service,java.math.BigDecimal.ONE,new pl.nclean.crm.records.ChemistryService.Forecast(false,Map.of()));assertFalse(unknown.defined());assertNull(unknown.cost());
        assertThrows(IllegalArgumentException.class,()->chemistry.saveMaterial(liquid,0,"Płyn","kg","1","50"));
        assertThrows(IllegalArgumentException.class,()->chemistry.quote(service,java.math.BigDecimal.ONE,new pl.nclean.crm.records.ChemistryService.Forecast(true,Map.of(liquid,new java.math.BigDecimal("-1")))));
        assertThrows(IllegalArgumentException.class,()->chemistry.saveMaterial(null,0,"Brak opakowania","l","0","50"));
    }

    @Test
    void missingStandardDoesNotBlockBookingAndInvalidForecastRollsBack() {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long service=estimateService("Usługa bez standardu");
        long id=data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Bez prognozy","500000072","Adres",Map.of(service,java.math.BigDecimal.ONE));
        assertNull(jdbc.queryForObject("SELECT chemical_cost FROM booking WHERE id=?",java.math.BigDecimal.class,id));assertFalse((Boolean)data.items(id).get(0).get("forecast_defined"));
        long before=jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class);
        assertThrows(IllegalArgumentException.class,()->data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Nie zapisz","500000073","Adres",Map.of(service,java.math.BigDecimal.ONE),Map.of(),Map.of(service,new pl.nclean.crm.records.ChemistryService.Forecast(true,Map.of(Long.MAX_VALUE,java.math.BigDecimal.ONE)))));
        assertEquals(before,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class));
        assertThrows(IllegalArgumentException.class,()->data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Nie zapisz ceny","500000074","Adres",Map.of(service,java.math.BigDecimal.ONE),Map.of(service,new java.math.BigDecimal("-1")),Map.of()));
        assertEquals(before,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Long.class));
    }

    @Test
    void actualUsageLearnsPerUnitMedianOnlyAfterFiveCompletedReportedBookings() {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var actual=app.context().getBean(pl.nclean.crm.records.ActualUsageService.class);
        long service=estimateService("Usługa nauki zużycia");long liquid=chemistry.saveMaterial(null,0,"Płukanka obserwowana","l","1","50");long other=chemistry.saveMaterial(null,0,"Drugi środek","ml","500","40");
        chemistry.saveRecipe(service,0,true,Map.of(liquid,new java.math.BigDecimal("50"),other,new java.math.BigDecimal("20")));
        var ids=new java.util.ArrayList<Long>();
        for(int index=0;index<7;index++){
            long id=data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Klient próby obserwacji","500000091","Adres próby",Map.of(service,new java.math.BigDecimal("2")));
            data.reschedule(id,0,java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,index==6?"CANCELLED":"DONE");ids.add(id);
        }
        assertTrue(actual.suggestions().isEmpty(),"Forecasts and completion alone are not observations");
        String[] perUnit={"0","50","60","70","1000"};
        for(int index=0;index<5;index++){
            actual.record(ids.get(index),0,0,Map.of(liquid,new java.math.BigDecimal(perUnit[index]).multiply(new java.math.BigDecimal("2"))));
            if(index<4)assertTrue(actual.suggestions().isEmpty());
        }
        var suggestion=actual.suggestions().get(service).get(0);assertEquals(5,suggestion.samples());assertEquals(0,new java.math.BigDecimal("60").compareTo(suggestion.quantity()));assertEquals(0,suggestion.minimum().signum());assertEquals(0,new java.math.BigDecimal("1000").compareTo(suggestion.maximum()));
        actual.apply(service,liquid,1);assertEquals(0,new java.math.BigDecimal("60").compareTo(chemistry.recipes().get(service).quantities().get(liquid)));assertEquals(0,new java.math.BigDecimal("20").compareTo(chemistry.recipes().get(service).quantities().get(other)));
        assertEquals(0,new java.math.BigDecimal("100").compareTo((java.math.BigDecimal)data.chemicals(ids.get(1)).stream().filter(row->((Number)row.get("chemical_id")).longValue()==liquid).findFirst().orElseThrow().get("quantity")),"Applying a standard does not rewrite old forecasts");
        actual.record(ids.get(0),0,1,Map.of(liquid,new java.math.BigDecimal("200")));
        var corrected=actual.suggestions().get(service).get(0);assertEquals(5,corrected.samples());assertEquals(0,new java.math.BigDecimal("70").compareTo(corrected.quantity()));
        data.reschedule(ids.get(1),1,java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,"CANCELLED");assertTrue(actual.suggestions().isEmpty());
        data.reschedule(ids.get(1),2,java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,"DONE");
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        assertEquals(5,app.context().getBean(pl.nclean.crm.records.ActualUsageService.class).suggestions().get(service).get(0).samples());
    }

    @Test
    void actualUsageRejectsUnfinishedInvalidAndStaleWritesAndBlankMeansUnknown() {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var actual=app.context().getBean(pl.nclean.crm.records.ActualUsageService.class);
        long service=estimateService("Usługa walidacji pomiarów");long material=chemistry.saveMaterial(null,0,"Środek rzeczywisty","l","1","40");
        long booking=data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Klient pomiarów","500000092","Adres",Map.of(service,java.math.BigDecimal.ONE));
        assertThrows(IllegalArgumentException.class,()->actual.record(booking,0,0,Map.of(material,java.math.BigDecimal.ONE)));
        data.reschedule(booking,0,java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,"DONE");
        assertThrows(IllegalArgumentException.class,()->actual.record(booking,0,0,Map.of(material,new java.math.BigDecimal("-1"))));
        assertThrows(IllegalArgumentException.class,()->actual.record(booking,0,0,Map.of(Long.MAX_VALUE,java.math.BigDecimal.ONE)));
        actual.record(booking,0,0,Map.of(material,java.math.BigDecimal.ZERO));assertTrue((Boolean)data.items(booking).get(0).get("actual_defined"));
        assertThrows(IllegalArgumentException.class,()->actual.record(booking,0,0,Map.of(material,new java.math.BigDecimal("100"))));
        assertEquals(0,((java.math.BigDecimal)data.actuals(booking).get(0).get("quantity")).signum());
        assertThrows(IllegalArgumentException.class,()->chemistry.saveMaterial(material,0,"Środek rzeczywisty","kg","1","40"));
        actual.record(booking,0,1,Map.of());assertFalse((Boolean)data.items(booking).get(0).get("actual_defined"));assertTrue(data.actuals(booking).isEmpty());
        assertNull(jdbc.queryForObject("SELECT chemical_cost FROM booking WHERE id=?",java.math.BigDecimal.class,booking));
    }

    @Test
    void actualUsageHttpAndSuggestionUseValidatedServerDataAndKeepUnitsSeparate() throws Exception {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var actual=app.context().getBean(pl.nclean.crm.records.ActualUsageService.class);
        long service=estimateService("Usługa jednostek pomiarów");long material=chemistry.saveMaterial(null,0,"Płyn jednostek","ml","1000","50");
        var browser=app.browser();browser.login();
        long first=0;
        for(int index=0;index<6;index++){
            long id=data.book(UUID.randomUUID(),java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,null,"Klient jednostek","500000093","Adres",Map.of(service,new java.math.BigDecimal("2")));
            data.reschedule(id,0,java.time.LocalDate.parse(DAY),java.time.LocalTime.NOON,"DONE");if(index==0)first=id;
            if(index<5){
                String path="/orders/"+id+"/items/0/actual";
                assertEquals(403,browser.settings(path,Map.of("calendar","1","version","0","actual_"+material,"120"),false).statusCode());
                assertEquals(200,browser.settings(path,Map.of("calendar","1","version","0","actual_"+material,"120"),true).statusCode());
            }
        }
        assertEquals(5,actual.suggestions().get(service).get(0).samples());
        assertEquals(302,browser.settings("/settings/services/"+service+"/suggestion",Map.of("chemical",material,"version","0","quantity","999999"),true).statusCode());
        assertEquals(0,new java.math.BigDecimal("60").compareTo(chemistry.recipes().get(service).quantities().get(material)));
        assertTrue(browser.get("/orders?day="+DAY).body().contains("Rzeczywiste zużycie chemii"));
        var fields=data.actualFields(Map.of(first,data.items(first)),data.chemicals(first),data.actuals(first));assertEquals(0,new java.math.BigDecimal("120").compareTo(fields.get(first+":0").get(material)));
        var current=data.services().stream().filter(v->((Number)v.get("id")).longValue()==service).findFirst().orElseThrow();
        data.service(service,((Number)current.get("version")).longValue(),((Number)current.get("category_id")).longValue(),"Usługa innej jednostki","pakiet","180",60,true);
        assertTrue(actual.suggestions().isEmpty(),"Different service units must not be mixed");
    }

    private static void assertCalendarRedirect(HttpResponse<String> response, String day) {
        assertEquals(302, response.statusCode());
        var target = URI.create(response.headers().firstValue("Location").orElseThrow());
        assertEquals("/calendar", target.getPath());
        assertEquals("month=" + day.substring(0, 7) + "&day=" + day + "&saved=1", target.getQuery());
    }
    private static void assertSettingsRedirect(HttpResponse<String> response) {
        assertEquals(302, response.statusCode());
        var target = URI.create(response.headers().firstValue("Location").orElseThrow());
        assertEquals("/settings/areas", target.getPath()); assertEquals("saved=1", target.getQuery());
    }
    private static void assertHtmlBadRequest(HttpResponse<String> response) {
        assertEquals(400, response.statusCode());
        assertTrue(response.headers().firstValue("Content-Type").orElse("").contains("text/html"));
    }


    @Test
    void dashboardUsesSnapshotsAndSeparatesPlanActualCancellationAndMissingData() {
        var dashboard=app.context().getBean(DashboardService.class);var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var actual=app.context().getBean(pl.nclean.crm.records.ActualUsageService.class);
        var date=DashboardService.today();long service=estimateService("Dashboard fotel");long liquid=chemistry.saveMaterial(null,0,"Płukanka dashboard","l","1","50");
        chemistry.saveRecipe(service,0,true,Map.of(liquid,new BigDecimal("100")));
        long first=data.book(UUID.randomUUID(),date,java.time.LocalTime.NOON,null,"Klient dashboard","500000096","Adres",Map.of(service,BigDecimal.ONE),Map.of(service,new BigDecimal("200")),Map.of());
        long second=data.book(UUID.randomUUID(),date,java.time.LocalTime.NOON,null,"Klient dashboard","500000096","Adres",Map.of(service,BigDecimal.ONE),Map.of(service,new BigDecimal("300")),Map.of());
        long cancelled=data.book(UUID.randomUUID(),date,java.time.LocalTime.NOON,null,"Klient dashboard","500000096","Adres",Map.of(service,BigDecimal.ONE));
        data.reschedule(first,0,date,java.time.LocalTime.NOON,"DONE");data.reschedule(cancelled,0,date,java.time.LocalTime.NOON,"CANCELLED");
        dashboard.saveMonth(YearMonth.from(date),-1,List.of(new DashboardService.Cost("Reklama","MARKETING",new BigDecimal("300")),new DashboardService.Cost("Telefon","PHONE",new BigDecimal("150"))));
        dashboard.saveFuel(date,-1,new BigDecimal("8"),new BigDecimal("6"),new BigDecimal("100"),new BigDecimal("50"),null);
        var plan=dashboard.summary(date,"day","plan");assertEquals(new BigDecimal("500.00"),plan.revenue());assertEquals(new BigDecimal("10.00"),plan.chemistry());assertEquals(new BigDecimal("48.00"),plan.fuel());assertEquals(1,plan.planned());assertEquals(1,plan.done());assertEquals(1,plan.cancelled());assertTrue(plan.complete());
        var unknown=dashboard.summary(date,"day","actual");assertEquals(1,unknown.missingChemistry());assertFalse(unknown.complete());assertEquals(new BigDecimal("200.00"),unknown.revenue());
        actual.record(first,0,0,Map.of(liquid,new BigDecimal("120")));chemistry.saveMaterial(liquid,0,"Płukanka dashboard","l","1","100");
        var done=dashboard.summary(date,"day","actual");assertTrue(done.complete());assertEquals(new BigDecimal("6.00"),done.chemistry());assertEquals(new BigDecimal("24.00"),done.fuel());
        actual.record(first,0,1,Map.of(liquid,new BigDecimal("140")));assertEquals(new BigDecimal("7.00"),dashboard.summary(date,"day","actual").chemistry(),"Editing quantity preserves price snapshot");
        actual.record(first,0,2,Map.of(liquid,BigDecimal.ZERO));assertTrue(dashboard.summary(date,"day","actual").complete());assertEquals(new BigDecimal("0.00"),dashboard.summary(date,"day","actual").chemistry());
        dashboard.saveFuel(date,0,new BigDecimal("8"),new BigDecimal("6"),new BigDecimal("100"),new BigDecimal("50"),new BigDecimal("12"));assertEquals(new BigDecimal("12.00"),dashboard.summary(date,"day","actual").fuel());
        assertEquals(new BigDecimal("500.00"),dashboard.summary(date,"day","plan").revenue());assertEquals(new BigDecimal("10.00"),dashboard.summary(date,"day","plan").chemistry());
    }

    @Test
    void dashboardMonthAllocationPersistsAndRejectsStaleAndClosedMonthChanges() {
        var dashboard=app.context().getBean(DashboardService.class);var date=DashboardService.today();var month=YearMonth.from(date);
        dashboard.saveMonth(month,-1,List.of(new DashboardService.Cost("Marketing","MARKETING",new BigDecimal("100.01")),new DashboardService.Cost("Stałe","OTHER",new BigDecimal("200.02"))));
        var summary=dashboard.summary(date,"month","actual");assertEquals(new BigDecimal("100.01"),summary.marketing());assertEquals(new BigDecimal("200.02"),summary.fixed());assertEquals(new BigDecimal("-300.03"),summary.remaining());assertEquals(month.lengthOfMonth(),summary.missingFuel());
        var initialDashboard=dashboard;assertThrows(IllegalArgumentException.class,()->initialDashboard.saveMonth(month,-1,List.of()));assertThrows(IllegalArgumentException.class,()->initialDashboard.saveMonth(month.minusMonths(1),-1,List.of()));
        dashboard.saveFuel(date,-1,BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO,null);assertThrows(IllegalArgumentException.class,()->initialDashboard.saveFuel(date,-1,BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO,null));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);dashboard=app.context().getBean(DashboardService.class);
        assertEquals(new BigDecimal("100.01"),dashboard.summary(date,"month","actual").marketing());assertEquals(new BigDecimal("0.00"),dashboard.summary(date,"day","actual").fuel());
    }

    @Test
    void dashboardHandlesCrossMonthWeekMissingPricesAndEmptyPeriods() {
        var dashboard=app.context().getBean(DashboardService.class);
        var empty=dashboard.summary(LocalDate.of(2028,2,10),"day","plan");assertTrue(empty.orders().isEmpty());assertEquals(new BigDecimal("0.00"),empty.costs());assertFalse(empty.complete());
        jdbc.update("INSERT INTO dashboard_month(month,configured) VALUES ('2026-12-01',TRUE),('2027-01-01',TRUE)");
        jdbc.update("INSERT INTO dashboard_month_cost(month,name,category,amount) VALUES ('2026-12-01','Grudzień','MARKETING',310),('2027-01-01','Styczeń','OTHER',620)");
        var week=dashboard.summary(LocalDate.of(2026,12,31),"week","plan");assertEquals(new BigDecimal("40.00"),week.marketing());assertEquals(new BigDecimal("60.00"),week.fixed());assertEquals(0,week.missingMonths());
        var historyDay=DashboardService.today().minusDays(1);var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long service=estimateService("Bez historycznej wyceny");var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);long chemical=chemistry.saveMaterial(null,0,"Stary pomiar","ml","1000","50");
        long id=data.book(UUID.randomUUID(),historyDay,java.time.LocalTime.NOON,null,"Klient próbny","500000095","Adres",Map.of(service,BigDecimal.ONE));data.reschedule(id,0,historyDay,java.time.LocalTime.NOON,"DONE");
        jdbc.update("UPDATE booking_item SET actual_defined=TRUE WHERE booking_id=?",id);jdbc.update("INSERT INTO booking_actual_chemical(booking_id,item_position,chemical_id,name,unit,quantity) VALUES (?,0,?,'Stary pomiar','ml',100)",id,chemical);
        assertEquals(1,dashboard.summary(historyDay,"day","actual").missingChemistry());
    }

    @Test
    void dashboardHttpRendersAndInvalidSavePreservesFormAndCsrf() throws Exception {
        var browser=app.browser();browser.login();var date=DashboardService.today();
        assertEquals(200,browser.get("/dashboard?date="+date).statusCode());assertEquals(200,browser.get("/dashboard?date="+date+"&range=month&mode=actual").statusCode());
        var costs=browser.get("/settings/costs?day="+date+"&month="+YearMonth.from(date));assertEquals(200,costs.statusCode());assertTrue(costs.body().contains("name=\"_csrf\""));
        var form=new LinkedHashMap<String,Object>();form.put("month",YearMonth.from(date));form.put("day",date);form.put("version",-1);form.put("name_0","Zapamiętaj reklamę");form.put("category_0","MARKETING");form.put("amount_0","-12");
        assertEquals(403,browser.settings("/settings/costs/month",form,false).statusCode());var invalid=browser.settings("/settings/costs/month",form,true);assertEquals(400,invalid.statusCode());assertTrue(invalid.body().contains("Zapamiętaj reklamę"));assertTrue(invalid.body().contains("value=\"-12\""));
        form.put("amount_0","300");assertEquals(302,browser.settings("/settings/costs/month",form,true).statusCode());assertEquals(400,browser.settings("/settings/costs/month",form,true).statusCode());assertEquals(400,browser.get("/dashboard?range=year").statusCode());
    }


    @Test
    void dashboardV7UpgradesOldMeasurementsOnlyWithMatchingHistoricalPrices() {
        String schema="dashboard_v6_upgrade";String url=POSTGRES.getJdbcUrl()+(POSTGRES.getJdbcUrl().contains("?")?"&":"?")+"currentSchema="+schema;
        var source=new DriverManagerDataSource(url,POSTGRES.getUsername(),POSTGRES.getPassword());var old=new JdbcTemplate(source);
        try {
            Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).target("6").load().migrate();
            long person=old.queryForObject("INSERT INTO crm_customer(name,phone) VALUES ('Test migracji','+48500000099') RETURNING id",Long.class);
            long service=old.queryForObject("SELECT min(id) FROM service_definition",Long.class);
            long material=old.queryForObject("INSERT INTO chemical(name,package_unit,package_quantity,package_price) VALUES ('Stara chemia','l',1,900) RETURNING id",Long.class);
            long booking=old.queryForObject("INSERT INTO booking(request_token,customer_id,day,starts,customer_name,phone,address,total,status) VALUES (?,?,CURRENT_DATE,'10:00','Test migracji','+48500000099','Adres',100,'DONE') RETURNING id",Long.class,UUID.randomUUID(),person);
            for(int i=0;i<3;i++){
                old.update("INSERT INTO booking_item(booking_id,position,service_id,name,unit,quantity,price,amount,suggested_price,actual_defined) VALUES (?,?,?,'Fotel','szt.',1,100,100,100,TRUE)",booking,i,service);
                old.update("INSERT INTO booking_actual_chemical(booking_id,item_position,chemical_id,name,unit,quantity) VALUES (?,?,?,'Stara chemia','ml',120)",booking,i,material);
            }
            old.update("INSERT INTO booking_chemical(booking_id,item_position,chemical_id,name,unit,quantity,unit_cost,amount) VALUES (?,0,?,'Stara chemia','ml',100,0.05,5),(?,1,?,'Stara chemia','g',100,0.05,5)",booking,material,booking,material);
            Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).load().migrate();
            assertEquals(new BigDecimal("6.00"),old.queryForObject("SELECT amount FROM booking_actual_chemical WHERE item_position=0",BigDecimal.class));
            assertNull(old.queryForObject("SELECT amount FROM booking_actual_chemical WHERE item_position=1",BigDecimal.class));assertNull(old.queryForObject("SELECT amount FROM booking_actual_chemical WHERE item_position=2",BigDecimal.class));
            assertEquals(new BigDecimal("900.00"),old.queryForObject("SELECT package_price FROM chemical",BigDecimal.class));
        }finally{jdbc.execute("DROP SCHEMA IF EXISTS "+schema+" CASCADE");}
    }

    @Test
    void dashboardPartialMeasurementsAndInvalidCostsRemainExplicit() {
        var dashboard=app.context().getBean(DashboardService.class);var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var actual=app.context().getBean(pl.nclean.crm.records.ActualUsageService.class);var date=DashboardService.today();
        long service=estimateService("Częściowy pomiar");long a=chemistry.saveMaterial(null,0,"Środek A","l","1","50"),b=chemistry.saveMaterial(null,0,"Środek B","l","1","50");chemistry.saveRecipe(service,0,true,Map.of(a,new BigDecimal("100"),b,new BigDecimal("100")));
        long booking=data.book(UUID.randomUUID(),date,java.time.LocalTime.NOON,null,"Klient próbny","500000099","Adres",Map.of(service,BigDecimal.ONE));data.reschedule(booking,0,date,java.time.LocalTime.NOON,"DONE");actual.record(booking,0,0,Map.of(a,new BigDecimal("100")));
        assertEquals(1,dashboard.summary(date,"day","actual").missingChemistry());actual.record(booking,0,1,Map.of(a,new BigDecimal("100"),b,BigDecimal.ZERO));assertEquals(0,dashboard.summary(date,"day","actual").missingChemistry());
        assertThrows(IllegalArgumentException.class,()->dashboard.saveMonth(YearMonth.from(date),-1,List.of(new DashboardService.Cost("Zły koszt",null,BigDecimal.ONE))));assertEquals(-1,dashboard.monthVersion(YearMonth.from(date)));
        assertThrows(IllegalArgumentException.class,()->dashboard.saveFuel(date,-1,new BigDecimal("-1"),BigDecimal.ONE,null,null,null));assertEquals(-1,((Number)dashboard.fuel(date).get("version")).longValue());
        dashboard.saveMonth(YearMonth.from(date),-1,List.of());dashboard.saveFuel(date,-1,BigDecimal.ONE,BigDecimal.ONE,BigDecimal.ZERO,BigDecimal.ZERO,null);assertTrue(dashboard.summary(date,"day","actual").complete());
    }


    private long seedFuelParameters(LocalDate date) {
        return jdbc.queryForObject("INSERT INTO fuel_parameters(request_token,effective_day,car_rate,generator_rate,car_fuel,generator_fuel,car_price,generator_price) VALUES (?,?,8,1.5,'DIESEL','PETROL',6,7) RETURNING id",Long.class,UUID.randomUUID(),date);
    }
    private pl.nclean.crm.fuel.FuelJournalService.Purchase purchaseInput(UUID token,LocalDate date,int minute,String litres,String odo,boolean full,boolean complete,String target,String type,UUID receipt) {
        return new pl.nclean.crm.fuel.FuelJournalService.Purchase(null,-1,token,date.atTime(0,minute),target,type,"60",litres,"",full,odo,complete,"Próba",receipt);
    }
    @Test void fuelReadingsHandleBaselineGapsCorrectionAndSnapshots() {
        var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var today=DashboardService.today();seedFuelParameters(today.minusDays(10));
        fuel.saveDay(today.minusDays(2),-1,"1000",0,0,false,OWNER);var baseline=fuel.usage(today.minusDays(2),today).get(today.minusDays(2));assertFalse(baseline.carKnown());assertNull(baseline.kilometres());
        fuel.saveDay(today,-1,"1100",1,30,false,OWNER);var gap=fuel.usage(today,today).get(today);assertFalse(gap.carKnown());assertEquals(new BigDecimal("100.0"),gap.kilometres());assertEquals(new BigDecimal("15.75"),gap.generatorCost());assertTrue(gap.note().contains("Brak podziału"));
        fuel.saveDay(today.minusDays(1),-1,"1050",0,0,false,OWNER);assertEquals(new BigDecimal("24.00"),fuel.usage(today,today).get(today).carCost());
        var originalFuel=fuel;assertThrows(IllegalArgumentException.class,()->originalFuel.saveDay(today.minusDays(1),0,"1060",0,0,false,OWNER));fuel.saveDay(today.minusDays(1),0,"1060",0,0,true,OWNER);assertEquals(new BigDecimal("19.20"),fuel.usage(today,today).get(today).carCost());
        assertThrows(IllegalArgumentException.class,()->originalFuel.saveDay(today.minusDays(1),0,"1060",0,0,true,OWNER));assertThrows(IllegalArgumentException.class,()->originalFuel.saveDay(today.minusDays(1),1,"1200",0,0,true,OWNER));assertThrows(IllegalArgumentException.class,()->originalFuel.saveDay(today,0,"1100",24,1,true,OWNER));
        fuel.saveParameters(UUID.randomUUID(),today,"20","3","DIESEL","PETROL","9","10");fuel.saveDay(today,0,"1100",2,0,true,OWNER);assertEquals(new BigDecimal("21.00"),fuel.usage(today,today).get(today).generatorCost());assertEquals(new BigDecimal("19.20"),fuel.usage(today,today).get(today).carCost());
        assertEquals(2,fuel.audit(today.minusDays(1)).size());assertEquals("1050.0",fuel.audit(today.minusDays(1)).get(0).get("old_odometer"));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);var restarted=fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);assertEquals(new BigDecimal("19.20"),restarted.usage(today,today).get(today).carCost());
    }
    @Test void fuelUnusualAndInvalidReadingsRequireExplicitConfirmation() {
        var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var today=DashboardService.today();seedFuelParameters(today.minusDays(1));fuel.saveDay(today.minusDays(1),-1,"1000",0,0,false,OWNER);
        assertThrows(IllegalArgumentException.class,()->fuel.saveDay(today,-1,"2500",17,0,false,OWNER));fuel.saveDay(today,-1,"2500",17,0,true,OWNER);
        assertThrows(IllegalArgumentException.class,()->fuel.saveDay(today,0,"-1",1,0,true,OWNER));assertThrows(IllegalArgumentException.class,()->fuel.saveDay(today.plusDays(1),-1,"2500",0,0,false,OWNER));assertThrows(IllegalArgumentException.class,()->fuel.saveParameters(UUID.randomUUID(),today.minusDays(1),"8","1","DIESEL","PETROL","6","6"));
    }
    @Test void fuelEstimatedCostAndPurchaseSpendingAreNotCountedTwiceAndLegacyOverridesSurvive() {
        var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var dash=app.context().getBean(DashboardService.class);var today=DashboardService.today();seedFuelParameters(today.minusDays(1));fuel.saveDay(today.minusDays(1),-1,"1000",0,0,false,OWNER);fuel.saveDay(today,-1,"1100",1,30,false,OWNER);
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,0,"10","",false,false,"GENERATOR","PETROL",null),OWNER);
        assertEquals(new BigDecimal("63.75"),dash.summary(today,"day","actual").fuel());assertEquals(new BigDecimal("60.00"),fuel.totals(today,today).purchases());assertEquals(new BigDecimal("8.000"),fuel.totals(today,today).carLitres());
        dash.saveFuel(today,-1,new BigDecimal("8"),new BigDecimal("6"),new BigDecimal("50"),new BigDecimal("50"),null);assertEquals(new BigDecimal("39.75"),dash.summary(today,"day","actual").fuel());
        dash.saveFuel(today,0,new BigDecimal("8"),new BigDecimal("6"),BigDecimal.ZERO,BigDecimal.ZERO,new BigDecimal("12"));assertEquals(new BigDecimal("12.00"),dash.summary(today,"day","actual").fuel());
        assertEquals(new BigDecimal("15.75"),dash.summary(today,"day","plan").fuel());
    }
    @Test void fuelFullToFullIncludesPartialPurchasesButExcludesOpeningFill() {
        var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var today=DashboardService.today();seedFuelParameters(today.minusDays(10));
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today.minusDays(1),0,"30","1000",true,false,"CAR","DIESEL",null),OWNER);
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,0,"3","1050",false,false,"CAR","DIESEL",null),OWNER);
        var token=UUID.randomUUID();var input=purchaseInput(token,today,1,"7","1100",true,true,"CAR","DIESEL",null);long ending=fuel.savePurchase(input,OWNER);assertEquals(ending,fuel.savePurchase(input,OWNER));assertEquals(3,fuel.purchases(today.minusDays(1),today).size());
        var comparison=fuel.comparisons(today).get(0);assertTrue(comparison.complete());assertEquals(new BigDecimal("10.000"),comparison.litres());assertEquals(new BigDecimal("10.000"),comparison.actualRate());assertEquals(new BigDecimal("8.000"),comparison.expectedLitres());assertEquals(new BigDecimal("25.00"),comparison.percent());
        assertThrows(IllegalArgumentException.class,()->fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,2,"5","900",true,true,"CAR","DIESEL",null),OWNER));
    }
    @Test void fuelMissingLitresTypesAndUnconfirmedRecordsDoNotClaimMeasuredConsumption() {
        var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var today=DashboardService.today();seedFuelParameters(today.minusDays(10));
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today.minusDays(1),0,"30","1000",true,false,"CAR","DIESEL",null),OWNER);
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,0,"","",false,false,"CAR","DIESEL",null),OWNER);fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,1,"10","1100",true,true,"CAR","DIESEL",null),OWNER);
        assertFalse(fuel.comparisons(today).get(0).complete());assertNull(fuel.comparisons(today).get(0).actualRate());assertEquals(new BigDecimal("120.00"),fuel.totals(today,today).purchases());
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,2,"10","1200",true,false,"CAR","DIESEL",null),OWNER);assertFalse(fuel.comparisons(today).get(0).complete());
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,3,"10","1300",true,true,"CAR","PETROL",null),OWNER);assertFalse(fuel.comparisons(today).get(0).complete());
        fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,4,"10","",false,false,"SHARED","PETROL",null),OWNER);assertEquals(3,fuel.comparisons(today).size());
    }
    @Test void fuelReceiptsValidateBytesStayPrivateAndSurviveRestartAndReplacement() throws Exception {
        var receipts=app.context().getBean(pl.nclean.crm.fuel.ReceiptService.class);var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var today=DashboardService.today();
        assertThrows(IllegalArgumentException.class,()->receipts.upload(new org.springframework.mock.web.MockMultipartFile("image","fake.jpg","image/jpeg","not an image".getBytes())));
        assertThrows(IllegalArgumentException.class,()->receipts.upload(new org.springframework.mock.web.MockMultipartFile("image","huge.jpg","image/jpeg",new byte[8*1024*1024+1])));
        var image=new java.awt.image.BufferedImage(8,8,java.awt.image.BufferedImage.TYPE_INT_RGB);var bytes=new java.io.ByteArrayOutputStream();javax.imageio.ImageIO.write(image,"png",bytes);
        UUID id=receipts.upload(new org.springframework.mock.web.MockMultipartFile("image","../../receipt.exe","text/plain",bytes.toByteArray()));assertTrue(receipts.image(id).length>0);
        var anonymous=app.browser();assertEquals(302,anonymous.get("/fuel/receipts/"+id).statusCode());anonymous.login();var picture=anonymous.get("/fuel/receipts/"+id);assertEquals(200,picture.statusCode());assertEquals("image/jpeg",picture.headers().firstValue("content-type").orElseThrow());assertTrue(picture.headers().firstValue("cache-control").orElseThrow().contains("no-store"));
        long purchase=fuel.savePurchase(purchaseInput(UUID.randomUUID(),today,0,"","",false,false,"SHARED","PETROL",id),OWNER);receipts.discard(id);assertTrue(receipts.image(id).length>0,"Linked image cannot be discarded");
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);var restartedReceipts=app.context().getBean(pl.nclean.crm.fuel.ReceiptService.class);var restartedFuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);assertTrue(restartedReceipts.image(id).length>0);
        restartedFuel.savePurchase(new pl.nclean.crm.fuel.FuelJournalService.Purchase(purchase,0,UUID.randomUUID(),today.atStartOfDay(),"SHARED","PETROL","65","","",false,"",false,"Korekta",null),OWNER);assertTrue(restartedReceipts.image(id).length>0,"Replaced receipt stays available through audit history");
        assertThrows(IllegalArgumentException.class,()->restartedFuel.savePurchase(new pl.nclean.crm.fuel.FuelJournalService.Purchase(purchase,0,UUID.randomUUID(),today.atStartOfDay(),"SHARED","PETROL","65","","",false,"",false,"Korekta",null),OWNER));
    }
    @Test void fuelFormsRenderAndFailedDayOrPurchasePreserveInputs() throws Exception {
        var browser=app.browser();browser.login();var today=DashboardService.today();seedFuelParameters(today.minusDays(1));
        assertEquals(200,browser.get("/fuel?date="+today).statusCode());assertEquals(200,browser.get("/dashboard?date="+today).statusCode());
        var invalid=browser.settings("/fuel/day",Map.of("day",today,"version",-1,"odometer","1234","hours",24,"minutes",1),true);assertEquals(400,invalid.statusCode());assertTrue(invalid.body().contains("value=\"1234\""));assertTrue(invalid.body().contains("value=\"24\""));
        var purchase=new LinkedHashMap<String,Object>();purchase.put("purchased_at",today.atStartOfDay());purchase.put("version",-1);purchase.put("request_token",UUID.randomUUID());purchase.put("amount","123");purchase.put("target","GENERATOR");purchase.put("fuel_type","PETROL");purchase.put("full_tank","on");purchase.put("note","Zachowaj dane rachunku");
        var error=browser.settings("/fuel/purchases",purchase,true);assertEquals(400,error.statusCode());assertTrue(error.body().contains("Zachowaj dane rachunku"));assertTrue(error.body().contains("value=\"123\""));
    }


    private long workBooking(String name,LocalDate day) {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long service=estimateService(name);
        return records.book(UUID.randomUUID(),day,java.time.LocalTime.of(9,0),null,"Klient dnia","500000098","Adres wizyty",Map.of(service,BigDecimal.ONE),Map.of(service,new BigDecimal("200")),Map.of());
    }
    @Test void completionKeepsQuoteAndPaymentsSeparateAndCorrectionsAuditable() {
        var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var date=DashboardService.today();long id=workBooking("Usługa domknięcia",date);
        work.complete(id,0,"180","60","Notatka",Map.of(),Map.of(),List.of(),OWNER);
        assertEquals(new BigDecimal("200.00"),work.order(id).get("total"));assertEquals(new BigDecimal("180.00"),work.order(id).get("final_total"));assertEquals(new BigDecimal("0"),work.paid(id));
        var token=UUID.randomUUID();long first=work.pay(id,token,date,"50","TRANSFER","");assertEquals(first,work.pay(id,token,date,"50","TRANSFER",""));work.pay(id,UUID.randomUUID(),date,"130","CASH","");assertEquals(new BigDecimal("180.00"),work.paid(id));
        assertThrows(IllegalArgumentException.class,()->work.pay(id,UUID.randomUUID(),date,"1","CASH",""));assertThrows(IllegalArgumentException.class,()->work.complete(id,1,"170","60","",Map.of(),Map.of(),List.of(),OWNER));
        work.reverse(id,first,UUID.randomUUID(),date,"Błędny przelew");assertEquals(new BigDecimal("130.00"),work.paid(id));assertEquals(3,work.payments(id).size());assertThrows(IllegalArgumentException.class,()->work.reverse(id,first,UUID.randomUUID(),date,"Ponownie"));
        assertEquals(new BigDecimal("50.00"),work.finance(date,date,new BigDecimal("180"),new BigDecimal("150"),true).outstanding());assertEquals(new BigDecimal("130.00"),work.finance(date,date,new BigDecimal("180"),new BigDecimal("150"),true).received());
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);assertEquals(new BigDecimal("130.00"),app.context().getBean(pl.nclean.crm.work.WorkService.class).paid(id));
    }
    @Test void timerSurvivesRestartAndOnlyOneCanRunAndManualRescheduleStopsIt() {
        var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var date=DashboardService.today();long id=workBooking("Pomiar A",date),other=workBooking("Pomiar B",date);work.timer(id,0,true,OWNER);
        assertThrows(IllegalArgumentException.class,()->work.timer(other,0,true,OWNER));jdbc.update("UPDATE booking SET timer_started=CURRENT_TIMESTAMP-INTERVAL '90 seconds' WHERE id=?",id);
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);var restarted=app.context().getBean(pl.nclean.crm.work.WorkService.class);assertEquals(id,((Number)restarted.active().get("id")).longValue());restarted.timer(id,1,false,OWNER);assertTrue(((Number)restarted.order(id).get("work_minutes")).intValue()>=2);
        restarted.timer(other,0,true,OWNER);app.context().getBean(pl.nclean.crm.records.CrmRecords.class).reschedule(other,1,date,java.time.LocalTime.NOON,"CANCELLED");assertTrue(restarted.active().isEmpty());assertFalse(restarted.history(other).isEmpty());
    }
    @Test void closingBundleNeedsExplicitBalancedAllocationAndActualConfirmation() {
        var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var chem=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var date=DashboardService.today();long a=estimateService("Pakiet A"),b=estimateService("Pakiet B"),material=chem.saveMaterial(null,0,"Płyn do pakietu","l","1","50");
        var quantities=new LinkedHashMap<Long,BigDecimal>();quantities.put(a,BigDecimal.ONE);quantities.put(b,BigDecimal.ONE);long id=records.book(UUID.randomUUID(),date,java.time.LocalTime.NOON,null,"Klient pakietu","500000097","Adres",quantities);
        assertThrows(IllegalArgumentException.class,()->work.complete(id,0,"300","90","",Map.of(0,new BigDecimal("100")),Map.of(),List.of(),OWNER));
        work.complete(id,0,"300","90","",Map.of(),Map.of(),List.of(),OWNER);assertNull(records.items(id).get(0).get("final_amount"));assertTrue(records.actuals(id).isEmpty());
        work.complete(id,1,"300","90","",Map.of(0,new BigDecimal("100"),1,new BigDecimal("200")),Map.of(0,30,1,60),List.of(new pl.nclean.crm.work.WorkService.Measurement(0,0,Map.of(material,BigDecimal.ZERO))),OWNER);
        assertEquals(new BigDecimal("100.00"),records.items(id).get(0).get("final_amount"));assertEquals(0,((BigDecimal)records.actuals(id).get(0).get("amount")).signum());assertFalse((Boolean)records.items(id).get(1).get("actual_defined"));
        var stats=work.analytics(date,date);assertEquals(2,stats.size());assertTrue(stats.stream().anyMatch(row->new BigDecimal("100.00").equals(row.get("net"))));
    }
    @Test void paymentDatesAreIndependentOfServiceDayAndFuturePaymentsAreRejected() {
        var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var today=DashboardService.today();long id=workBooking("Wczorajsza usługa",today.minusDays(1));work.complete(id,0,"200","60","",Map.of(),Map.of(),List.of(),OWNER);work.pay(id,UUID.randomUUID(),today,"100","CARD","");
        assertEquals(new BigDecimal("0"),work.finance(today.minusDays(1),today.minusDays(1),new BigDecimal("200"),BigDecimal.ZERO,false).received());assertEquals(new BigDecimal("100.00"),work.finance(today,today,BigDecimal.ZERO,BigDecimal.ZERO,false).received());
        assertThrows(IllegalArgumentException.class,()->work.pay(id,UUID.randomUUID(),today.plusDays(1),"100","CASH",""));
        assertEquals(new BigDecimal("200.00"),app.context().getBean(DashboardService.class).summary(today.minusDays(1),"day","actual").revenue());
    }
    @Test void workScreensAndCsvAndPwaRenderWithoutPublicCustomerData() throws Exception {
        long id=workBooking("Usługa interfejsu",DashboardService.today());var browser=app.browser();browser.login();
        for(String path:List.of("/today","/work/"+id,"/dashboard?mode=actual","/orders?repeat="+id,"/customers/"+app.context().getBean(pl.nclean.crm.work.WorkService.class).order(id).get("customer_id")))assertEquals(200,browser.get(path).statusCode(),path);
        var invalid=browser.settings("/work/"+id+"/complete",Map.of("version",0,"final_total","-12","minutes","30","note","Zachowaj formularz"),true);assertEquals(400,invalid.statusCode());assertTrue(invalid.body().contains("Zachowaj formularz"));
        assertEquals(403,browser.settings("/work/"+id+"/timer",Map.of("version",0,"action","start"),false).statusCode());assertEquals(302,browser.settings("/work/"+id+"/timer",Map.of("version",0,"action","start"),true).statusCode());assertEquals(200,browser.get("/export/orders.csv").statusCode());var anonymous=app.browser();assertEquals(302,anonymous.get("/export/orders.csv").statusCode());assertEquals(200,anonymous.get("/manifest.webmanifest").statusCode());assertEquals(200,anonymous.get("/pwa/icon-192.png").statusCode());
    }


    private org.springframework.mock.web.MockMultipartFile serviceImage(String name) throws Exception {var image=new java.awt.image.BufferedImage(8,8,java.awt.image.BufferedImage.TYPE_INT_RGB);var bytes=new java.io.ByteArrayOutputStream();javax.imageio.ImageIO.write(image,"png",bytes);return new org.springframework.mock.web.MockMultipartFile("image",name,"image/png",bytes.toByteArray());}
    @Test void photosDeriveTimePreserveManualPriorityAndArePrivateAndDurable() throws Exception {
        var context=app.context().getBean(pl.nclean.crm.context.ContextService.class);var day=DashboardService.today();long id=workBooking("Usługa zdjęciowa",day);String date=day.toString().replace("-","");var token=UUID.randomUUID();var before=serviceImage("IMG_"+date+"_103025.jpg");UUID first=context.upload(id,"BEFORE",token,before,OWNER,0);assertEquals(first,context.upload(id,"BEFORE",token,before,OWNER,0));assertNull(context.time(id).minutes());
        UUID after=context.upload(id,"AFTER",UUID.randomUUID(),serviceImage("IMG_"+date+"_111025.jpg"),OWNER,1);assertEquals(40L,context.time(id).minutes());assertEquals(40,jdbc.queryForObject("SELECT work_minutes FROM booking WHERE id=?",Integer.class,id));assertEquals("PHOTO",jdbc.queryForObject("SELECT work_time_source FROM booking WHERE id=?",String.class,id));
        var browser=app.browser();assertEquals(302,browser.get("/photos/"+first).statusCode());browser.login();assertEquals(200,browser.get("/photos/"+first).statusCode());
        context.manualTime(id,2,day.atTime(10,0),day.atTime(11,0),OWNER);context.delete(id,after,OWNER);assertEquals(60,jdbc.queryForObject("SELECT work_minutes FROM booking WHERE id=?",Integer.class,id));
        context.upload(id,"AFTER",UUID.randomUUID(),serviceImage("bez-daty.png"),OWNER,4);assertNull(context.time(id).minutes());assertEquals(60,jdbc.queryForObject("SELECT work_minutes FROM booking WHERE id=?",Integer.class,id));assertEquals("MANUAL",jdbc.queryForObject("SELECT work_time_source FROM booking WHERE id=?",String.class,id));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);assertTrue(app.context().getBean(pl.nclean.crm.context.ContextService.class).image(first).length>0);
    }
    @Test void unknownPhotoDeletionAndConflictingDatesNeverBecomeAnInventedTime() throws Exception {
        var context=app.context().getBean(pl.nclean.crm.context.ContextService.class);var day=DashboardService.today();long id=workBooking("Niepełne zdjęcia",day);String date=day.toString().replace("-","");context.upload(id,"BEFORE",UUID.randomUUID(),serviceImage("IMG_"+date+"_120000.jpg"),OWNER,0);context.upload(id,"AFTER",UUID.randomUUID(),serviceImage("IMG_"+date+"_110000.jpg"),OWNER,1);assertNull(context.time(id).minutes());assertNull(jdbc.queryForObject("SELECT work_minutes FROM booking WHERE id=?",Integer.class,id));assertThrows(IllegalArgumentException.class,()->context.upload(id,"AFTER",UUID.randomUUID(),serviceImage("x.png"),OWNER,0));
        var photos=context.photos(id);context.delete(id,(UUID)photos.get(0).get("id"),OWNER);assertNull(context.time(id).minutes());
    }
    @Test void customerSourceNotesSearchAndCallbacksPreserveHistory() {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var context=app.context().getBean(pl.nclean.crm.context.ContextService.class);var day=DashboardService.today().minusMonths(7);long service=estimateService("Usługa powrotu");long id=data.book(UUID.randomUUID(),day,java.time.LocalTime.NOON,null,"Anna Źródło","500000096","Adres szukany",Map.of(service,BigDecimal.ONE),Map.of(),Map.of(),"REFERRAL","Od Ewy","Piętro 3, jest winda");var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);long person=((Number)work.order(id).get("customer_id")).longValue();data.reschedule(id,0,day,java.time.LocalTime.NOON,"DONE");assertEquals("REFERRAL",jdbc.queryForObject("SELECT source FROM crm_customer WHERE id=?",String.class,person));assertEquals("Piętro 3, jest winda",work.order(id).get("work_note"));assertEquals(2,context.search("500000096").size());assertEquals(2,context.search("szukany").size());assertTrue(context.search("x").isEmpty());assertTrue(context.callbacks().stream().anyMatch(c->((Number)c.get("id")).longValue()==person));
        var token=UUID.randomUUID();context.contact(person,0,token,DashboardService.today().plusMonths(1),"Rozmawiałem");context.contact(person,0,token,DashboardService.today().plusMonths(1),"Ponowienie");assertEquals(1,context.contacts(person).size());assertTrue(context.callbacks().isEmpty());
        jdbc.update("UPDATE crm_customer SET contact_due=CURRENT_DATE-1 WHERE id=?",person);data.book(UUID.randomUUID(),DashboardService.today().plusDays(2),java.time.LocalTime.NOON,person,null,null,"Inny adres",Map.of(service,BigDecimal.ONE));assertTrue(context.callbacks().isEmpty());assertEquals("REFERRAL",jdbc.queryForObject("SELECT source FROM crm_customer WHERE id=?",String.class,person));
    }


    @Test void explicitTimerReplacesEstimatedPhotoTimeAndNewPhotosCannotOverwriteTimer() throws Exception {
        var context=app.context().getBean(pl.nclean.crm.context.ContextService.class);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var day=DashboardService.today();String date=day.toString().replace("-","");long id=workBooking("Zdjęcia i timer",day);context.upload(id,"BEFORE",UUID.randomUUID(),serviceImage("IMG_"+date+"_100000.jpg"),OWNER,0);context.upload(id,"AFTER",UUID.randomUUID(),serviceImage("IMG_"+date+"_104000.jpg"),OWNER,1);assertEquals(40,work.order(id).get("work_minutes"));work.timer(id,2,true,OWNER);assertNull(work.order(id).get("work_minutes"));context.upload(id,"AFTER",UUID.randomUUID(),serviceImage("IMG_"+date+"_110000.jpg"),OWNER,3);assertNull(work.order(id).get("work_minutes"));work.timer(id,4,false,OWNER);assertEquals("TIMER",work.order(id).get("work_time_source"));assertTrue(((Number)work.order(id).get("work_minutes")).intValue()<40);
    }


    @Test void movingPhotoDerivedVisitClearsInvalidAutomaticTimeWithoutChangingManualHistory() throws Exception {
        var context=app.context().getBean(pl.nclean.crm.context.ContextService.class);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var day=DashboardService.today();String date=day.toString().replace("-","");long id=workBooking("Zmiana dnia zdjęć",day);context.upload(id,"BEFORE",UUID.randomUUID(),serviceImage("IMG_"+date+"_100000.jpg"),OWNER,0);context.upload(id,"AFTER",UUID.randomUUID(),serviceImage("IMG_"+date+"_104000.jpg"),OWNER,1);app.context().getBean(pl.nclean.crm.records.CrmRecords.class).reschedule(id,2,day.plusDays(1),java.time.LocalTime.NOON,"PLANNED");assertNull(work.order(id).get("work_minutes"));assertEquals("UNKNOWN",work.order(id).get("work_time_source"));assertEquals(2,context.photos(id).size());
    }

    private record RunningApp(ConfigurableApplicationContext context, URI base) implements AutoCloseable {
        static RunningApp start() {
            return start(false);
        }

        static RunningApp start(boolean pixelTycoon) { return start(pixelTycoon, ""); }

        static RunningApp start(boolean pixelTycoon, String contextPath) {
            // Do not inherit database URLs, active profiles, or config files from the caller.
            var environment = new StandardEnvironment();
            environment.getPropertySources().remove(StandardEnvironment.SYSTEM_ENVIRONMENT_PROPERTY_SOURCE_NAME);
            environment.getPropertySources().remove(StandardEnvironment.SYSTEM_PROPERTIES_PROPERTY_SOURCE_NAME);
            environment.getPropertySources().addFirst(new MapPropertySource("isolated-integration-test", Map.ofEntries(
                Map.entry("spring.config.location", "classpath:/application.yml"),
                Map.entry("spring.profiles.active", pixelTycoon ? "integration,tycoon" : "integration"),
                Map.entry("spring.datasource.url", POSTGRES.getJdbcUrl()),
                Map.entry("spring.datasource.username", POSTGRES.getUsername()),
                Map.entry("spring.datasource.password", POSTGRES.getPassword()),
                Map.entry("crm.admin.username", OWNER),
                Map.entry("crm.admin.password-hash", PASSWORD_HASH),
                Map.entry("server.address", "127.0.0.1"),
                Map.entry("server.port", "0"),
                Map.entry("server.servlet.context-path", contextPath),
                Map.entry("spring.main.banner-mode", "off"))));
            var context = new SpringApplicationBuilder(CrmApplication.class)
                .environment(environment).web(WebApplicationType.SERVLET).registerShutdownHook(false).run();
            int port = ((ServletWebServerApplicationContext) context).getWebServer().getPort();
            return new RunningApp(context, URI.create("http://127.0.0.1:" + port + contextPath));
        }

        Browser browser() { return new Browser(base); }
        @Override public void close() { context.close(); }
    }


    private Map<String,String> reviewFields(long id) {
        var b=app.context().getBean(pl.nclean.crm.work.WorkService.class).order(id);
        var f=new LinkedHashMap<String,String>();f.put("version",b.get("version").toString());f.put("outcome","DONE");f.put("final_total","0");f.put("no_notes","on");f.put("before_exception","Klient odmówił");f.put("after_exception","Klient odmówił");
        for(var item:app.context().getBean(pl.nclean.crm.records.CrmRecords.class).items(id)){String pos=item.get("position").toString();f.put("actualVersion_"+pos,item.get("actual_version").toString());f.put("chem_"+pos,"ZERO");}return f;
    }
    @Test void reviewSeparatesAppointmentNotesAndAcceptsZeroWithExplicitExceptions() {
        var day=DashboardService.today();long id=workBooking("Przegląd",day);jdbc.update("UPDATE booking SET work_note='Parking od tyłu' WHERE id=?",id);
        var service=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);assertEquals(0,service.review(day).complete());
        var f=reviewFields(id);f.remove("no_notes");f.put("note","Klient zadowolony");service.save(id,day,f,OWNER);
        var order=app.context().getBean(pl.nclean.crm.work.WorkService.class).order(id);assertEquals("Parking od tyłu",order.get("work_note"));assertEquals("Klient zadowolony",order.get("completion_note"));assertEquals(1,service.review(day).complete());assertEquals(0,((BigDecimal)order.get("final_total")).signum());
        assertTrue((Boolean)app.context().getBean(pl.nclean.crm.records.CrmRecords.class).items(id).get(0).get("actual_no_chem"));
    }
    @Test void reviewClosurePersistsAndReopensForNewOrdersAndPhotoChanges() throws Exception {
        var day=DashboardService.today();long id=workBooking("Zamknięcie",day);var service=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);service.save(id,day,reviewFields(id),OWNER);
        var r=service.review(day);service.close(day,r.fingerprint(),OWNER);assertTrue(service.review(day).closed());app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);service=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);assertTrue(service.review(day).closed());
        var context=app.context().getBean(pl.nclean.crm.context.ContextService.class);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);context.upload(id,"BEFORE",UUID.randomUUID(),serviceImage("IMG_20261111_100000.jpg"),OWNER,((Number)work.order(id).get("version")).longValue());assertFalse(service.review(day).closed());assertTrue(service.review(day).changed());
        service.close(day,service.review(day).fingerprint(),OWNER);workBooking("Nowa wizyta",day);assertFalse(service.review(day).closed());
    }
    @Test void reviewBlocksMissingFieldsUnknownChemistryAndStaleWrites() {
        var day=DashboardService.today();long id=workBooking("Braki",day);var service=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);var f=reviewFields(id);f.put("chem_0","KEEP");f.remove("before_exception");f.remove("after_exception");f.remove("no_notes");service.save(id,day,f,OWNER);
        var r=service.review(day);assertEquals(0,r.complete());assertTrue(r.orders().get(0).get("missing").toString().contains("chemia"));assertThrows(IllegalArgumentException.class,()->service.close(day,r.fingerprint(),OWNER));assertThrows(IllegalArgumentException.class,()->service.save(id,day,f,OWNER));
        var fresh=reviewFields(id);fresh.put("chem_0","MEASURED");assertThrows(IllegalArgumentException.class,()->service.save(id,day,fresh,OWNER));assertEquals(0,service.review(day).complete());
    }
    @Test void reviewMovesAndCancelsWithoutInventingMeasurementsOrPayments() {
        var day=DashboardService.today();long id=workBooking("Przełożenie",day);var service=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);var f=reviewFields(id);f.put("outcome","MOVED");f.put("new_day",day.plusDays(2).toString());f.put("new_starts","13:30");f.put("reason","Na prośbę klienta");service.save(id,day,f,OWNER);assertTrue(service.review(day).orders().isEmpty());assertEquals(1,service.review(day).moves().size());assertEquals(1,service.review(day.plusDays(2)).orders().size());
        long cancelled=workBooking("Anulowanie",day);f=reviewFields(cancelled);f.put("outcome","CANCELLED");service.save(cancelled,day,f,OWNER);assertEquals(1,service.review(day).complete());assertTrue(app.context().getBean(pl.nclean.crm.records.CrmRecords.class).actuals(cancelled).isEmpty());
    }
    @Test void reviewEmptyDayAndPartialPaymentAndHttpSecurity() throws Exception {
        var day=DashboardService.today();var service=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);service.close(day,service.review(day).fingerprint(),OWNER);assertTrue(service.review(day).closed());long id=workBooking("Przelew oczekujący",day);var f=reviewFields(id);f.put("final_total","200");service.save(id,day,f,OWNER);app.context().getBean(pl.nclean.crm.work.WorkService.class).pay(id,UUID.randomUUID(),day,"50","TRANSFER","");assertEquals(1,service.review(day).complete());
        var browser=app.browser();browser.login();assertEquals(200,browser.get("/day-closeout?date="+day).statusCode());assertEquals(302,app.browser().get("/day-closeout").statusCode());assertEquals(403,browser.settings("/day-closeout/close",Map.of("date",day,"fingerprint",service.review(day).fingerprint()),false).statusCode());
        var stale=service.review(day).fingerprint();jdbc.update("UPDATE booking SET completion_note='Korekta' WHERE id=?",id);assertThrows(IllegalArgumentException.class,()->service.close(day,stale,OWNER));
    }

    @Test void concurrentPhotoAndClosureDoNotLeaveStaleClosedDayOrDeadlock() throws Exception {
        var day=DashboardService.today();long id=workBooking("Równoczesne zdjęcie",day);var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);review.save(id,day,reviewFields(id),OWNER);String fingerprint=review.review(day).fingerprint();long version=((Number)app.context().getBean(pl.nclean.crm.work.WorkService.class).order(id).get("version")).longValue();var image=serviceImage("IMG_20261111_100000.jpg");var photos=app.context().getBean(pl.nclean.crm.context.ContextService.class);
        var gate=new java.util.concurrent.CountDownLatch(1);var pool=java.util.concurrent.Executors.newFixedThreadPool(2);
        try{var close=pool.submit(()->{gate.await();try{review.close(day,fingerprint,OWNER);}catch(IllegalArgumentException expected){assertTrue(expected.getMessage().contains("innym oknie"));}return true;});var upload=pool.submit(()->{gate.await();photos.upload(id,"AFTER",UUID.randomUUID(),image,OWNER,version);return true;});gate.countDown();assertTrue(close.get(20,java.util.concurrent.TimeUnit.SECONDS));assertTrue(upload.get(20,java.util.concurrent.TimeUnit.SECONDS));assertFalse(review.review(day).closed());}finally{pool.shutdownNow();}
        var future=day.plusDays(1);assertThrows(IllegalArgumentException.class,()->review.close(future,review.review(future).fingerprint(),OWNER));
    }

    @Test void auditGenericCancellationCannotHideExistingPayments() {
        var day=DashboardService.today();long id=workBooking("Anulowanie z wpłatą",day);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long payment=work.pay(id,UUID.randomUUID(),day,"50","TRANSFER","");
        assertThrows(IllegalArgumentException.class,()->records.reschedule(id,0,day,java.time.LocalTime.NOON,"CANCELLED"));assertEquals("PLANNED",work.order(id).get("status"));assertEquals(new BigDecimal("50.00"),work.paid(id));
        work.reverse(id,payment,UUID.randomUUID(),day,"Rozliczenie wpłaty");records.reschedule(id,0,day,java.time.LocalTime.NOON,"CANCELLED");assertEquals("CANCELLED",work.order(id).get("status"));
    }
    @Test void auditConcurrentBookingReplayReturnsSameIdAndOneCustomer() throws Exception {
        var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long service=estimateService("Jedna rezerwacja");var token=UUID.randomUUID();var day=DashboardService.today();var gate=new java.util.concurrent.CountDownLatch(1);var pool=java.util.concurrent.Executors.newFixedThreadPool(2);
        try{java.util.concurrent.Callable<Long> create=()->{gate.await();return data.book(token,day,java.time.LocalTime.NOON,null,"Próba równoczesna","500000096","Adres",Map.of(service,BigDecimal.ONE));};var a=pool.submit(create);var b=pool.submit(create);gate.countDown();assertEquals(a.get(20,java.util.concurrent.TimeUnit.SECONDS),b.get(20,java.util.concurrent.TimeUnit.SECONDS));assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM booking",Integer.class));assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Integer.class));}finally{pool.shutdownNow();}
    }
    @Test void auditKnownCostsDoNotConfirmUnconfirmedFinalPrice() {
        var day=DashboardService.today();long id=workBooking("Cena niepotwierdzona",day);var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);records.reschedule(id,0,day,java.time.LocalTime.NOON,"DONE");app.context().getBean(pl.nclean.crm.records.ActualUsageService.class).zero(id,0,0);
        var dashboard=app.context().getBean(DashboardService.class);dashboard.saveMonth(YearMonth.from(day),-1,List.of());dashboard.saveFuel(day,-1,BigDecimal.ONE,BigDecimal.ONE,BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO);
        var s=dashboard.summary(day,"day","actual");assertTrue(s.complete());assertFalse(s.financialComplete());assertEquals(1,s.unconfirmedPrices());
        var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);work.complete(id,1,"100","60","",Map.of(),Map.of(),List.of(),OWNER);assertTrue(dashboard.summary(day,"day","actual").financialComplete());
    }
    @Test void auditExplicitNoChemistryHasKnownZeroServiceCost() {
        long id=workBooking("Jawne zero chemii",DashboardService.today());var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);var f=reviewFields(id);f.put("final_total","120");review.save(id,DashboardService.today(),f,OWNER);var analytics=app.context().getBean(pl.nclean.crm.work.WorkService.class).analytics(DashboardService.today(),DashboardService.today());assertEquals(new BigDecimal("120.00"),analytics.get(0).get("net"));assertEquals(0,((BigDecimal)analytics.get(0).get("chemical_cost")).signum());
    }
    @Test void auditSecurityHeadersProtectAuthenticatedViewsAndLogin() throws Exception {
        var browser=app.browser();var login=browser.get("/login");assertTrue(login.headers().firstValue("Content-Security-Policy").orElse("").contains("frame-ancestors 'none'"));assertEquals("same-origin",login.headers().firstValue("Referrer-Policy").orElse(""));browser.login();var page=browser.get("/calendar");assertEquals("DENY",page.headers().firstValue("X-Frame-Options").orElse(""));assertEquals("nosniff",page.headers().firstValue("X-Content-Type-Options").orElse(""));assertTrue(page.headers().firstValue("Cache-Control").orElse("").contains("no-store"));
    }

    @Test void auditOrdinaryPriceCorrectionPreservesExplicitNoNotes() {
        var day=DashboardService.today();long id=workBooking("Korekta bez uwag",day);app.context().getBean(pl.nclean.crm.work.DayReviewService.class).save(id,day,reviewFields(id),OWNER);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);work.complete(id,1,"100","","",Map.of(),Map.of(),List.of(),OWNER);assertTrue((Boolean)work.order(id).get("completion_no_notes"));work.complete(id,2,"100","","Nowa uwaga",Map.of(),Map.of(),List.of(),OWNER);assertFalse((Boolean)work.order(id).get("completion_no_notes"));assertEquals("Nowa uwaga",work.order(id).get("completion_note"));
    }

    @Test void notesPersistAndPinsAreLimitedAndSharedAcrossPeriods() throws Exception {
        var notes=app.context().getBean(pl.nclean.crm.notes.NoteService.class);var token=UUID.randomUUID();long id=notes.save(null,0,token,"NOTE","Luźna myśl","Treść\nDrugi wiersz",null,true,List.of());assertEquals(id,notes.save(null,0,token,"NOTE","Luźna myśl","Treść\nDrugi wiersz",null,true,List.of()));
        for(int n=0;n<4;n++)notes.save(null,0,UUID.randomUUID(),"TASK","Zadanie "+n,"",DashboardService.today().plusDays(n),true,List.of());assertEquals(3,notes.pinned().size());assertEquals(5,notes.pinnedCount());assertEquals("TASK",notes.pinned().get(0).kind());
        var browser=app.browser();browser.login();for(String range:List.of("day","week","month")){var response=browser.get("/dashboard?range="+range);assertEquals(200,response.statusCode());assertTrue(response.body().contains("Pokaż wszystkie przypięte (5)"));}
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);notes=app.context().getBean(pl.nclean.crm.notes.NoteService.class);assertEquals("Treść\nDrugi wiersz",notes.get(id).content());assertEquals(5,notes.pinnedCount());
    }
    @Test void notesArchiveRestoreKeepCompletionAndDoNotChangeDayClosure() {
        var notes=app.context().getBean(pl.nclean.crm.notes.NoteService.class);var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);var day=DashboardService.today();review.close(day,review.review(day).fingerprint(),OWNER);long id=notes.save(null,0,UUID.randomUUID(),"TASK","Zadanie do odhaczenia","",null,true,List.of());notes.action(id,0,"done",null,false);assertTrue(notes.pinned().isEmpty());assertTrue(notes.get(id).completed());notes.action(id,1,"archive",null,false);notes.action(id,2,"restore",null,false);assertTrue(notes.get(id).completed());assertFalse(notes.get(id).archived());notes.action(id,3,"reopen",null,false);assertEquals(1,notes.pinnedCount());notes.action(id,4,"unpin",null,false);assertTrue(notes.pinned().isEmpty());assertEquals(1,notes.list("active","",false,0).total());assertTrue(review.review(day).closed());
    }
    @Test void goalsHaveManualCompletionAndVersionedSteps() {
        var notes=app.context().getBean(pl.nclean.crm.notes.NoteService.class);var step=UUID.randomUUID();long id=notes.save(null,0,UUID.randomUUID(),"GOAL","Cel","",DashboardService.today().minusDays(1),true,List.of(new pl.nclean.crm.notes.NoteService.Step(step,"Pierwszy krok",false)));assertTrue(notes.get(id).overdue());notes.action(id,0,"step",step,true);assertEquals(1,notes.get(id).doneSteps());assertFalse(notes.get(id).completed());assertThrows(IllegalArgumentException.class,()->notes.action(id,0,"done",null,false));notes.action(id,1,"done",null,false);assertTrue(notes.get(id).completed());assertFalse(notes.get(id).overdue());
        long empty=notes.save(null,0,UUID.randomUUID(),"GOAL","Cel bez kroków","",null,false,List.of());assertTrue(notes.get(empty).steps().isEmpty());
        long memo=notes.save(null,0,UUID.randomUUID(),"NOTE","Data notatki","",DashboardService.today().minusDays(1),false,List.of());assertFalse(notes.get(memo).overdue());assertThrows(IllegalArgumentException.class,()->notes.action(memo,0,"done",null,false));
    }
    @Test void notesValidateEscapeAndPreserveStaleEditor() throws Exception {
        var notes=app.context().getBean(pl.nclean.crm.notes.NoteService.class);var token=UUID.randomUUID();assertThrows(IllegalArgumentException.class,()->notes.save(null,0,token,"NOTE"," ","",null,false,List.of()));assertThrows(IllegalArgumentException.class,()->notes.save(null,0,token,"NOTE","Tytuł","x".repeat(5001),null,false,List.of()));var many=new ArrayList<pl.nclean.crm.notes.NoteService.Step>();for(int n=0;n<31;n++)many.add(new pl.nclean.crm.notes.NoteService.Step(UUID.randomUUID(),"Krok",false));assertThrows(IllegalArgumentException.class,()->notes.save(null,0,token,"GOAL","Cel","",null,false,many));
        long id=notes.save(null,0,token,"NOTE","<script>alert(1)</script>","needle memo",null,false,List.of());notes.save(id,0,token,"NOTE","<script>alert(1)</script>","needle changed",null,false,List.of());assertThrows(IllegalArgumentException.class,()->notes.save(id,0,token,"NOTE","Stara karta","stare",null,false,List.of()));assertEquals("needle changed",notes.get(id).content());assertEquals(1,notes.list("active","NEEDLE",false,0).total());var browser=app.browser();browser.login();var response=browser.get("/notes");assertEquals(200,response.statusCode());assertTrue(response.body().contains("&lt;script&gt;alert(1)&lt;/script&gt;"));assertEquals(200,browser.get("/notes/editor?id="+id).statusCode());assertEquals(403,browser.settings("/notes/"+id+"/action",Map.of("version",1,"action","archive"),false).statusCode());assertEquals(302,app.browser().get("/notes").statusCode());
    }
    @Test void concurrentNoteCreationIsIdempotentAndEditorsCannotOverwriteActions() throws Exception {
        var notes=app.context().getBean(pl.nclean.crm.notes.NoteService.class);var token=UUID.randomUUID();var gate=new java.util.concurrent.CountDownLatch(1);var pool=java.util.concurrent.Executors.newFixedThreadPool(2);
        try{java.util.concurrent.Callable<Long> save=()->{gate.await();return notes.save(null,0,token,"TASK","Jedno zadanie","",null,true,List.of());};var a=pool.submit(save);var b=pool.submit(save);gate.countDown();long id=a.get(20,java.util.concurrent.TimeUnit.SECONDS);assertEquals(id,b.get(20,java.util.concurrent.TimeUnit.SECONDS));notes.action(id,0,"done",null,false);assertThrows(IllegalArgumentException.class,()->notes.save(id,0,token,"TASK","Stary edytor","",null,true,List.of()));assertTrue(notes.get(id).completed());assertEquals(1,notes.list("done","",false,0).total());}finally{pool.shutdownNow();}
    }

    private Map<String,String> expense(String category,String title,String amount){var p=new LinkedHashMap<String,String>();p.put("token",UUID.randomUUID().toString());p.put("version","0");p.put("category",category);p.put("title",title);p.put("amount",amount);p.put("spent_on",DashboardService.today().toString());return p;}
    @Test void costBookReusesFuelAndSeparatesInvestmentFromOperatingCosts() {
        var day=DashboardService.today();var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);fuel.savePurchase(purchaseInput(UUID.randomUUID(),day,0,"","",false,false,"CAR","PETROL",null),OWNER);
        var repair=expense("CAR_REPAIR","Hamulce","200");repair.put("odometer","120000");long id=costs.save(repair,OWNER);assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM fuel_day",Integer.class));assertEquals(2,costs.entries(day,day,"car","",false,0).size());assertEquals(new BigDecimal("60.00"),costs.totals(day,day).get("fuel"));assertEquals(new BigDecimal("260.00"),costs.totals(day,day).get("all"));
        var equipment=expense("EQUIPMENT_PURCHASE","Ekstraktor","1000");equipment.put("quantity","2");long purchase=costs.save(equipment,OWNER);assertEquals(purchase,costs.save(equipment,OWNER));assertEquals(1,costs.assets().size());assertEquals(new BigDecimal("1000.00"),costs.investments(day,day));assertEquals(new BigDecimal("200.00"),costs.operating(day,day));var summary=app.context().getBean(DashboardService.class).summary(day,"day","actual");assertEquals(new BigDecimal("200.00"),summary.operating());assertEquals(new BigDecimal("1000.00"),summary.investments());assertEquals(new BigDecimal("-200.00"),summary.remaining());assertEquals(5,summary.slices().size());
        repair.put("id",Long.toString(id));repair.put("amount","250");costs.save(repair,OWNER);assertEquals(new BigDecimal("250.00"),costs.operating(day,day));costs.cancel(id,1,"Błędny rachunek",OWNER);assertEquals(0,costs.operating(day,day).signum());assertEquals(0,app.context().getBean(DashboardService.class).summary(day,"day","actual").remaining().signum());assertTrue((Boolean)costs.entry(id).get("cancelled"));assertEquals(3,costs.audit(id).size());
    }
    @Test void chemistryPurchasesDoNotChangeHistoricalCostsOrCatalogue() {
        var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);var chem=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);long liquid=chem.saveMaterial(null,0,"Płyn","l","1","40");long id=workBooking("Pomiar",DashboardService.today());var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);work.complete(id,0,"200","60","",Map.of(),Map.of(),List.of(new pl.nclean.crm.work.WorkService.Measurement(0,0,Map.of(liquid,new BigDecimal("100")))),OWNER);var p=expense("CHEMISTRY","Nowa butelka","80");p.put("chemical_id",Long.toString(liquid));p.put("quantity","2");costs.save(p,OWNER);assertEquals(new BigDecimal("40.00"),chem.materials().get(0).packagePrice());assertEquals(new BigDecimal("4.00"),app.context().getBean(DashboardService.class).summary(DashboardService.today(),"day","actual").chemistry());assertEquals(new BigDecimal("80.00"),costs.totals(DashboardService.today(),DashboardService.today()).get("chemistry"));assertEquals(0,costs.operating(DashboardService.today(),DashboardService.today()).signum());assertEquals(1,costs.usage(DashboardService.today(),DashboardService.today()).size());
    }
    @Test void monthlyReceiptDoesNotDuplicateCostAndCannotLoseItsLink() {
        var day=DashboardService.today();var dashboard=app.context().getBean(DashboardService.class);var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);dashboard.saveMonth(YearMonth.from(day),-1,List.of(new DashboardService.Cost("Reklama","MARKETING",new BigDecimal("300"))));var p=expense("MARKETING","Rachunek za reklamę","300");p.put("covered","on");p.put("covered_month",YearMonth.from(day).toString());p.put("covered_category","MARKETING");long id=costs.save(p,OWNER);assertEquals(0,costs.operating(day,day).signum());assertEquals(new BigDecimal("300.00"),costs.totals(day,day).get("all"));assertEquals(new BigDecimal("300.00"),dashboard.summary(day,"month","actual").marketing());assertThrows(IllegalArgumentException.class,()->dashboard.saveMonth(YearMonth.from(day),0,List.of()));var once=expense("MARKETING","Ulotki","50");costs.save(once,OWNER);assertEquals(new BigDecimal("350.00"),dashboard.summary(day,"month","actual").marketing());assertEquals(0,dashboard.summary(day,"month","actual").operating().signum());
        costs.cancel(id,0,"Duplikat dokumentu",OWNER);dashboard.saveMonth(YearMonth.from(day),0,List.of());assertEquals(new BigDecimal("50.00"),dashboard.summary(day,"month","actual").marketing());
    }
    @Test void assetHistoryAndReceiptSurviveCorrectionsCancellationAndRestart() throws Exception {
        var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);var receipts=app.context().getBean(pl.nclean.crm.fuel.ReceiptService.class);UUID picture=receipts.upload(serviceImage("rachunek.jpg"));var p=expense("EQUIPMENT_PURCHASE","Agregat","2000");p.put("receipt_id",picture.toString());long id=costs.save(p,OWNER);long asset=((Number)costs.entry(id).get("asset_id")).longValue();var service=expense("EQUIPMENT_SERVICE","Wymiana oleju agregatu","100");service.put("asset_id",Long.toString(asset));costs.save(service,OWNER);assertEquals(2,costs.assetHistory(asset).size());receipts.discard(picture);assertTrue(receipts.image(picture).length>0);
        p.put("id",Long.toString(id));p.put("receipt_id","");costs.save(p,OWNER);jdbc.update("UPDATE fuel_receipt SET created_at=CURRENT_TIMESTAMP-INTERVAL '2 days' WHERE id=?",picture);receipts.upload(serviceImage("nowe.jpg"));receipts.discard(picture);assertTrue(receipts.image(picture).length>0,"Historical expense receipt must not be purged");
        var fields=new LinkedHashMap<String,String>();fields.put("name","Agregat po serwisie");fields.put("category","Agregaty");costs.editAsset(asset,0,fields,OWNER);assertFalse((Boolean)costs.asset(asset).get("active"));assertEquals(2,costs.assetHistory(asset).size());var stale=expense("EQUIPMENT_SERVICE","Nowy serwis","1");stale.put("asset_id",Long.toString(asset));assertThrows(IllegalArgumentException.class,()->costs.save(stale,OWNER));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);assertEquals(2,app.context().getBean(pl.nclean.crm.costs.CostService.class).assetHistory(asset).size());assertTrue(app.context().getBean(pl.nclean.crm.fuel.ReceiptService.class).image(picture).length>0);
    }
    @Test void cancelledFuelIsExcludedEverywhereButHistoryAndReceiptRemain() throws Exception {
        var day=DashboardService.today();var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var receipt=app.context().getBean(pl.nclean.crm.fuel.ReceiptService.class);UUID image=receipt.upload(serviceImage("paliwo.jpg"));long id=fuel.savePurchase(purchaseInput(UUID.randomUUID(),day,0,"","",false,false,"CAR","PETROL",image),OWNER);fuel.cancelPurchase(id,0,"Pomyłka",OWNER);assertEquals(0,fuel.totals(day,day).purchases().signum());assertEquals(0,app.context().getBean(pl.nclean.crm.costs.CostService.class).totals(day,day).get("all").signum());assertEquals(1,fuel.purchases(day,day).size());assertTrue((Boolean)fuel.purchase(id).get("cancelled"));receipt.discard(image);assertTrue(receipt.image(image).length>0);assertTrue(fuel.comparisons(day).isEmpty());
    }
    @Test void expenseValidationVersionPrivacyAndAllViewsRender() throws Exception {
        var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);var bad=expense("CAR_REPAIR","Naprawa","-1");assertThrows(IllegalArgumentException.class,()->costs.save(bad,OWNER));var p=expense("CAR_SERVICE","Wymiana oleju","150");long id=costs.save(p,OWNER);p.put("id",Long.toString(id));costs.save(p,OWNER);assertThrows(IllegalArgumentException.class,()->costs.save(p,OWNER));var browser=app.browser();browser.login();for(String view:List.of("overview","car","equipment","chemistry","fixed","all"))assertEquals(200,browser.get("/costs?view="+view).statusCode(),view);assertEquals(200,browser.get("/costs?range=year").statusCode());assertEquals(200,browser.get("/costs/editor?id="+id).statusCode());assertEquals(403,browser.settings("/costs/"+id+"/cancel",Map.of("version",1,"reason","Test"),false).statusCode());assertEquals(302,app.browser().get("/costs").statusCode());assertEquals(0,costs.totals(DashboardService.today().minusYears(1),DashboardService.today().minusYears(1)).get("all").signum());
    }

    @Test void expenseDateCorrectionsShiftPeriodsAndReceiptsCannotBeDoubleLinked() throws Exception {
        var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);var receipts=app.context().getBean(pl.nclean.crm.fuel.ReceiptService.class);var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var day=DashboardService.today();UUID image=receipts.upload(serviceImage("koszt.jpg"));var p=expense("CAR_PARTS","Część","10");p.put("receipt_id",image.toString());long id=costs.save(p,OWNER);assertThrows(IllegalArgumentException.class,()->fuel.savePurchase(purchaseInput(UUID.randomUUID(),day,0,"","",false,false,"CAR","PETROL",image),OWNER));p.put("id",Long.toString(id));var earlier=day.minusMonths(1);p.put("spent_on",earlier.toString());costs.save(p,OWNER);assertEquals(0,costs.totals(day.withDayOfMonth(1),YearMonth.from(day).atEndOfMonth()).get("all").signum());assertEquals(new BigDecimal("10.00"),costs.totals(earlier.withDayOfYear(1),earlier.withMonth(12).withDayOfMonth(31)).get("all"));
        var future=expense("OTHER","Przyszły rachunek","5");future.put("spent_on",day.plusDays(1).toString());assertThrows(IllegalArgumentException.class,()->costs.save(future,OWNER));assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM cost_entry",Integer.class));
    }
    @Test
    void customerSearchKeepsFilterInUrlAndLegacyPostStillWorks() throws Exception {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        records.saveCustomer(null,0,"Klient Alfa","500000001","Adres Alfa","",true);
        records.saveCustomer(null,0,"Klient Beta","500000002","Adres Beta","",true);
        var browser=app.browser();browser.login();
        var result=browser.get("/customers?query=Alfa");
        assertEquals(200,result.statusCode());assertTrue(result.body().contains("Klient Alfa"));assertFalse(result.body().contains("Klient Beta"));
        assertTrue(result.body().contains("value=\"Alfa\""));assertTrue(result.body().contains("method=\"get\""));
        assertFalse(result.body().contains("action=\"/customers/search\""));
        var reloaded=browser.get("/customers?query=Alfa");assertTrue(reloaded.body().contains("Klient Alfa"));assertFalse(reloaded.body().contains("Klient Beta"));
        var legacy=browser.settings("/customers/search",Map.of("query","Klient Alfa"),true);
        assertEquals(302,legacy.statusCode());assertEquals("/customers?query=Klient+Alfa",URI.create(legacy.headers().firstValue("Location").orElseThrow()).getPath()+"?"+URI.create(legacy.headers().firstValue("Location").orElseThrow()).getRawQuery());
        assertEquals(400,browser.get("/customers?query="+"a".repeat(121)).statusCode());
        var escaped=browser.get("/customers?query="+URLEncoder.encode("\"><script>alert(1)</script>",StandardCharsets.UTF_8));
        assertEquals(200,escaped.statusCode());assertFalse(escaped.body().contains("<script>alert(1)</script>"));
        assertTrue(browser.get("/customers?query=500000002").body().contains("Klient Beta"));
    }

    @Test
    void v12CopyUpgradesWithoutChangingBookingsFuelImagesNotesOrMonthlyCosts() {
        String schema="upgrade_v12_costs";
        var source=new DriverManagerDataSource(POSTGRES.getJdbcUrl()+(POSTGRES.getJdbcUrl().contains("?")?"&":"?")+"currentSchema="+schema,POSTGRES.getUsername(),POSTGRES.getPassword());
        var old=new JdbcTemplate(source);
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).target("12").load().migrate();
        long person=old.queryForObject("INSERT INTO crm_customer(name,phone) VALUES ('Kopia testowa','+48500000099') RETURNING id",Long.class);
        long booking=old.queryForObject("INSERT INTO booking(request_token,customer_id,day,starts,customer_name,phone,address,total) VALUES (?,?,DATE '2026-10-28',TIME '10:00','Kopia testowa','+48500000099','Historyczny adres',180) RETURNING id",Long.class,UUID.randomUUID(),person);
        long service=old.queryForObject("SELECT min(id) FROM service_definition",Long.class);
        old.update("INSERT INTO booking_item(booking_id,position,service_id,name,unit,quantity,price,amount,suggested_price) VALUES (?,0,?,'Historyczna usługa','szt.',1,180,180,180)",booking,service);
        var receipt=UUID.randomUUID();byte[] image={1,2,3,4};old.update("INSERT INTO fuel_receipt(id,image) VALUES (?,?)",receipt,image);
        long fuel=old.queryForObject("INSERT INTO fuel_purchase(request_token,purchased_at,target,fuel_type,amount,receipt_id) VALUES (?,TIMESTAMP '2026-10-28 10:00','CAR','DIESEL',200,?) RETURNING id",Long.class,UUID.randomUUID(),receipt);
        old.update("INSERT INTO memo_entry(request_token,kind,title,pinned) VALUES (?,'NOTE','Historyczne memo',true)",UUID.randomUUID());
        old.update("INSERT INTO dashboard_month(month,configured) VALUES (DATE '2026-10-01',true)");old.update("INSERT INTO dashboard_month_cost(month,name,category,amount) VALUES (DATE '2026-10-01','Reklama','MARKETING',300)");
        var beforeBooking=old.queryForMap("SELECT * FROM booking WHERE id=?",booking);var beforeItem=old.queryForMap("SELECT * FROM booking_item WHERE booking_id=?",booking);var beforeNote=old.queryForMap("SELECT * FROM memo_entry");
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).load().migrate();
        var afterBooking=old.queryForMap("SELECT * FROM booking WHERE id=?",booking);assertNull(afterBooking.remove("removed_at"));assertEquals(false,afterBooking.remove("historical"));assertEquals(beforeBooking,afterBooking);assertEquals(beforeItem,old.queryForMap("SELECT * FROM booking_item WHERE booking_id=?",booking));assertEquals(beforeNote,old.queryForMap("SELECT * FROM memo_entry"));
        assertArrayEquals(image,old.queryForObject("SELECT image FROM fuel_receipt WHERE id=?",byte[].class,receipt));assertEquals(new BigDecimal("200.00"),old.queryForObject("SELECT amount FROM fuel_purchase WHERE id=?",BigDecimal.class,fuel));assertFalse(old.queryForObject("SELECT cancelled FROM fuel_purchase WHERE id=?",Boolean.class,fuel));
        assertEquals(new BigDecimal("300.00"),old.queryForObject("SELECT amount FROM dashboard_month_cost",BigDecimal.class));assertEquals(0,old.queryForObject("SELECT count(*) FROM cost_entry",Integer.class));assertEquals(16,old.queryForObject("SELECT count(*) FROM flyway_schema_history WHERE success AND type='SQL'",Integer.class));
    }

    @Test
    void tycoonIsDefaultAcrossRoutesAndRestartPreservesDataAndSecurity() throws Exception {
        long booking=workBooking("Motyw nie zmienia danych",DashboardService.today());
        var original=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",booking);
        var classic=app.browser();classic.login();
        assertTrue(classic.get("/calendar").body().contains("/css/tycoon.css"));
        assertTrue(classic.get("/dashboard").body().contains("/pixel/base.svg"));
        app.close();app=RunningApp.start(true);jdbc=app.context().getBean(JdbcTemplate.class);
        assertEquals(302,app.browser().get("/calendar").statusCode());
        var experiment=app.browser();experiment.login();
        for(String path:List.of("/calendar","/today","/customers","/settings","/settings/areas","/settings/services","/settings/costs","/dashboard","/fuel","/costs","/notes","/day-closeout","/work/"+booking)){
            var page=experiment.get(path);assertEquals(200,page.statusCode(),path);
            assertTrue(page.body().contains("/css/tycoon.css"),path);assertTrue(page.body().contains("/js/tycoon.js"),path);
            assertTrue(page.body().contains("ncLEANEK"),path);assertFalse(page.body().contains(">TYCOON<"),path);
        }
        assertTrue(experiment.get("/dashboard").body().contains("/pixel/base.svg"));
        assertEquals(200,experiment.get("/pixel/base.svg").statusCode());
        assertEquals(403,experiment.settings("/customers",Map.of("name","Bez CSRF","phone","500000099"),false).statusCode());
        assertEquals(original,jdbc.queryForMap("SELECT * FROM booking WHERE id=?",booking));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        var restored=app.browser();restored.login();assertTrue(restored.get("/calendar").body().contains("/css/tycoon.css"));
        assertEquals(original,jdbc.queryForMap("SELECT * FROM booking WHERE id=?",booking));
    }

    @Test void tycoonMilestonesFollowCommittedWorkAndKeepHistoryAfterCorrection() throws Exception {
        var awards=app.context().getBean(pl.nclean.crm.tycoon.AchievementService.class);
        var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        var day=DashboardService.today();long id=workBooking("Pierwsza odznaka",day);
        assertThrows(IllegalArgumentException.class,()->work.complete(id,0,"-1","60","",Map.of(),Map.of(),List.of(),OWNER));
        assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        var tx=new org.springframework.transaction.support.TransactionTemplate(app.context().getBean(org.springframework.transaction.PlatformTransactionManager.class));
        tx.executeWithoutResult(t->{work.complete(id,0,"180","60","",Map.of(),Map.of(),List.of(),OWNER);t.setRollbackOnly();});
        assertEquals("PLANNED",work.order(id).get("status"));assertEquals(0,awards.performedCount());
        assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        work.complete(id,0,"180","60","",Map.of(),Map.of(),List.of(),OWNER);awards.performed(id);
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        assertEquals("EVENT",jdbc.queryForObject("SELECT origin FROM tycoon_award",String.class));
        for(int n=1;n<10;n++){long next=workBooking("Licznik "+n,day);records.reschedule(next,0,day,java.time.LocalTime.NOON,"DONE");}
        assertEquals(10,awards.performedCount());assertEquals(2,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        long future=workBooking("Przyszłe",day.plusDays(1));jdbc.update("UPDATE booking SET status='DONE' WHERE id=?",future);awards.performed(future);
        assertEquals(10,awards.performedCount());
        records.reschedule(id,1,day,java.time.LocalTime.NOON,"CANCELLED");assertEquals(9,awards.performedCount());
        assertTrue(awards.badges().stream().filter(b->b.get("code").equals("TEN_CLEAN")).allMatch(b->Boolean.TRUE.equals(b.get("earned"))&&b.get("current").equals(9L)));
        var before=jdbc.queryForMap("SELECT * FROM tycoon_award WHERE code='TEN_CLEAN'");
        app.close();app=RunningApp.start(true);jdbc=app.context().getBean(JdbcTemplate.class);
        assertEquals(before,jdbc.queryForMap("SELECT * FROM tycoon_award WHERE code='TEN_CLEAN'"));
        var browser=app.browser();browser.login();var read=browser.get("/tycoon/progress?date="+day);assertEquals(200,read.statusCode());assertTrue(read.body().contains("\"performed\":9"));
        assertEquals(400,browser.get("/tycoon/progress?date=1900-01-01").statusCode());
        assertEquals(403,browser.settings("/tycoon/achievements/TEN_CLEAN/ack",Map.of(),false).statusCode());
        assertEquals(400,browser.settings("/tycoon/achievements/UNKNOWN/ack",Map.of(),true).statusCode());
    }

    @Test void tycoonNotificationIsClaimedOnceAcrossTabsAndRestart() throws Exception {
        long id=workBooking("Jedna wiadomość",DashboardService.today());
        app.context().getBean(pl.nclean.crm.work.WorkService.class).complete(id,0,"120","30","",Map.of(),Map.of(),List.of(),OWNER);
        var awards=app.context().getBean(pl.nclean.crm.tycoon.AchievementService.class);
        assertTrue(awards.badges().stream().anyMatch(b->Boolean.TRUE.equals(b.get("pending"))));
        var pool=java.util.concurrent.Executors.newFixedThreadPool(2);var gate=new java.util.concurrent.CountDownLatch(1);
        try{java.util.concurrent.Callable<Boolean> claim=()->{gate.await();return awards.acknowledge("FIRST_CLEAN");};var a=pool.submit(claim);var b=pool.submit(claim);gate.countDown();assertNotEquals(a.get(10,java.util.concurrent.TimeUnit.SECONDS),b.get(10,java.util.concurrent.TimeUnit.SECONDS));}finally{pool.shutdownNow();}
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        assertFalse(app.context().getBean(pl.nclean.crm.tycoon.AchievementService.class).acknowledge("FIRST_CLEAN"));
        assertFalse(app.context().getBean(pl.nclean.crm.tycoon.AchievementService.class).badges().stream().anyMatch(b->Boolean.TRUE.equals(b.get("pending"))));
    }

    @Test void tycoonDayBadgeRequiresNonemptyValidCloseoutAndKeepsHistoricAward() {
        var day=DashboardService.today();var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);
        review.close(day,review.review(day).fingerprint(),OWNER);assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        long id=workBooking("Tycoon dokumentacja",day);assertThrows(IllegalArgumentException.class,()->review.close(day,review.review(day).fingerprint(),OWNER));
        review.save(id,day,reviewFields(id),OWNER);assertEquals(1,review.review(day).complete());
        assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM tycoon_award WHERE code='FIRST_DAY'",Integer.class));
        review.close(day,review.review(day).fingerprint(),OWNER);review.close(day,review.review(day).fingerprint(),OWNER);
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM tycoon_award WHERE code='FIRST_DAY'",Integer.class));
        workBooking("Tycoon dodatkowa wizyta",day);assertFalse(review.review(day).closed());
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM tycoon_award WHERE code='FIRST_DAY'",Integer.class));
    }

    @Test void tycoonGoalUsesExistingStepsAndExplicitCompletion() {
        var notes=app.context().getBean(pl.nclean.crm.notes.NoteService.class);var step=UUID.randomUUID();
        long id=notes.save(null,0,UUID.randomUUID(),"GOAL","Cel z krokami","",null,true,List.of(new pl.nclean.crm.notes.NoteService.Step(step,"Krok",false)));
        notes.action(id,0,"step",step,true);assertEquals(1,notes.pinnedGoal().doneSteps());
        assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        assertThrows(IllegalArgumentException.class,()->notes.action(id,0,"done",null,false));
        notes.action(id,1,"done",null,false);assertNull(notes.pinnedGoal());
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM tycoon_award WHERE code='FIRST_GOAL'",Integer.class));
        notes.action(id,2,"reopen",null,false);assertEquals(id,notes.pinnedGoal().id());
        notes.action(id,3,"done",null,false);assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        long task=notes.save(null,0,UUID.randomUUID(),"TASK","Zadanie","",null,true,List.of());notes.action(task,0,"done",null,false);
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
    }

    @Test void v14RecognizesHistoricMilestonesWithoutPopupsOrChangingDomainData() {
        String schema="upgrade_v14_tycoon";
        var source=new DriverManagerDataSource(POSTGRES.getJdbcUrl()+(POSTGRES.getJdbcUrl().contains("?")?"&":"?")+"currentSchema="+schema,POSTGRES.getUsername(),POSTGRES.getPassword());
        var old=new JdbcTemplate(source);Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).target("13").load().migrate();
        long person=old.queryForObject("INSERT INTO crm_customer(name,phone) VALUES ('Historyczny klient','500000099') RETURNING id",Long.class);
        for(int i=0;i<50;i++)old.update("INSERT INTO booking(request_token,customer_id,day,starts,customer_name,phone,address,total,status) VALUES (?,?,CURRENT_DATE,TIME '10:00','Syntetyczny klient','500000099','Adres testowy',180,'DONE')",UUID.randomUUID(),person);
        old.update("INSERT INTO memo_entry(request_token,kind,title,completed) VALUES (?,'GOAL','Historyczny cel',true)",UUID.randomUUID());
        var before=old.queryForList("SELECT * FROM booking ORDER BY id");var goal=old.queryForMap("SELECT * FROM memo_entry");
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).load().migrate();
        var after=old.queryForList("SELECT * FROM booking ORDER BY id");after.forEach(row->{assertNull(row.remove("removed_at"));assertEquals(false,row.remove("historical"));});assertEquals(before,after);assertEquals(goal,old.queryForMap("SELECT * FROM memo_entry"));
        assertEquals(4,old.queryForObject("SELECT count(*) FROM tycoon_award WHERE origin='HISTORY' AND notified_at IS NOT NULL",Integer.class));
        assertEquals(0,old.queryForObject("SELECT count(*) FROM tycoon_award WHERE code='FIRST_DAY'",Integer.class));
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).load().migrate();assertEquals(4,old.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
    }

    @Test void animationSignalsCarryTheCommittedBookingIdAndNeverAppearOnError() throws Exception {
        var browser=app.browser();browser.login();long service=((Number)app.context().getBean(pl.nclean.crm.records.CrmRecords.class).services().get(0).get("id")).longValue();
        var fields=new LinkedHashMap<String,Object>();fields.put("token",UUID.randomUUID());fields.put("day",DashboardService.today());fields.put("starts","09:30");fields.put("name","Klient reakcji");fields.put("phone","500000097");fields.put("address","Adres próbny");fields.put("qty_"+service,"1");fields.put("calendar","1");
        var first=browser.settings("/orders",fields,true);assertEquals(200,first.statusCode());
        long id=jdbc.queryForObject("SELECT id FROM booking WHERE request_token=?::uuid",Long.class,fields.get("token").toString());
        assertTrue(first.body().contains("\"id\":"+id));assertTrue(first.body().contains("\"motion\":\"booked\""));
        var retry=browser.settings("/orders",fields,true);assertEquals(200,retry.statusCode());assertTrue(retry.body().contains("\"id\":"+id));
        var update=Map.of("calendar","1","version","0","day",DashboardService.today().toString(),"starts","11:00","status","CANCELLED");
        var saved=browser.settings("/orders/"+id,update,true);assertEquals(200,saved.statusCode());assertTrue(saved.body().contains("\"motion\":\"updated\""));
        var stale=browser.settings("/orders/"+id,update,true);assertEquals(400,stale.statusCode());assertFalse(stale.body().contains("\"motion\""));assertFalse(stale.body().contains("\"saved\":true"));
    }

    @Test void nativeCompletionUsesOneTimeServerFlashInsteadOfTrustingSavedQuery() throws Exception {
        long id=workBooking("Animacja rzeczywistego wykonania",DashboardService.today());app.close();app=RunningApp.start(true);jdbc=app.context().getBean(JdbcTemplate.class);
        var browser=app.browser();browser.login();String path="/work/"+id;
        assertFalse(browser.get(path+"?saved=1").body().contains("name=\"crm-confirmed\""));
        var bad=browser.settings(path+"/complete",Map.of("version","0","final_total","-1","minutes","30"),true);assertEquals(400,bad.statusCode());assertFalse(bad.body().contains("name=\"crm-confirmed\""));
        assertEquals("PLANNED",jdbc.queryForObject("SELECT status FROM booking WHERE id=?",String.class,id));
        var good=browser.settings(path+"/complete",Map.of("version","0","final_total","150","minutes","30"),true);assertEquals(302,good.statusCode());
        var page=browser.get(path+"?saved=1");assertEquals(200,page.statusCode());assertTrue(page.body().contains("name=\"crm-confirmed\""));assertTrue(page.body().contains("data-kind=\"completed\""));assertTrue(page.body().contains("data-order=\""+id+"\""));
        assertFalse(browser.get(path+"?saved=1").body().contains("name=\"crm-confirmed\""));
        assertTrue(page.body().contains("/js/tycoon-motion.js"));
    }

    @Test void leanNavigationSeparatesWorkFromSettingsAndUsesAuthoritativeDayReview() throws Exception {
        long id=workBooking("Lean braki dokumentacji",DashboardService.today());var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);work.complete(id,0,"180","60","",Map.of(),Map.of(),List.of(),OWNER);
        var browser=app.browser();browser.login();assertEquals(302,app.browser().get("/more").statusCode());
        var more=browser.get("/more");assertEquals(200,more.statusCode());assertTrue(more.body().contains("href=\"/dashboard\""));assertTrue(more.body().contains("href=\"/costs\""));
        var settings=browser.get("/settings");assertEquals(200,settings.statusCode());assertFalse(settings.body().contains("href=\"/dashboard\""));assertTrue(settings.body().contains("href=\"/settings/services\""));
        var dashboard=browser.get("/dashboard");assertEquals(200,dashboard.statusCode());assertTrue(Pattern.compile("href=\"/more\"[^>]*aria-current=\"page\"").matcher(dashboard.body()).find());
        var today=browser.get("/today");assertEquals(200,today.statusCode());assertTrue(today.body().contains("0 z 1 zleceń uzupełnionych"));assertTrue(today.body().contains("zdjęcie przed"));
        var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);review.save(id,DashboardService.today(),reviewFields(id),OWNER);
        assertTrue(browser.get("/today").body().contains("1 z 1 zleceń uzupełnionych"));
        var order=browser.get("/work/"+id);assertEquals(200,order.statusCode());assertTrue(order.body().contains("id=\"complete-form\""));assertTrue(order.body().contains("action=\"/day-closeout/"+id+"\""));assertFalse(order.body().contains("action=\"/work/"+id+"/complete\""));
    }

    @Test void sharedCompletionRetainsOptionalAllocationsAndRejectsInvalidSumAtomically() {
        var day=DashboardService.today();var data=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long first=estimateService("Lean pakiet A"),second=estimateService("Lean pakiet B");
        long id=data.book(UUID.randomUUID(),day,java.time.LocalTime.NOON,null,"Pakiet testowy","500000093","Adres pakietu",Map.of(first,BigDecimal.ONE,second,BigDecimal.ONE));
        var fields=reviewFields(id);fields.put("final_total","300");fields.put("minutes","90");fields.put("allocations","1");fields.put("amount_0","100");fields.put("amount_1","200");fields.put("time_0","30");fields.put("time_1","60");
        var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);review.save(id,day,fields,OWNER);assertEquals(new BigDecimal("100.00"),data.items(id).get(0).get("final_amount"));assertEquals(90,app.context().getBean(pl.nclean.crm.work.WorkService.class).order(id).get("work_minutes"));
        var before=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id);fields.put("version","1");fields.put("amount_1","500");assertThrows(IllegalArgumentException.class,()->review.save(id,day,fields,OWNER));assertEquals(before,jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id));
    }

    @Test void futureDoneRejectedAtomicallyThroughEveryWriteEntry() throws Exception {
        var day=DashboardService.today();long id=workBooking("Przyszła wizyta",day.plusDays(1));
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);
        var before=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id);var items=records.items(id);
        var browser=app.browser();browser.login();
        assertEquals(400,browser.settings("/orders/"+id,Map.of("calendar","1","version","0","day",day.plusDays(1),"starts","12:00","status","DONE"),true).statusCode());
        assertEquals(400,browser.settings("/work/"+id+"/complete",Map.of("version","0","final_total","100","minutes","45","note","Pomiar"),true).statusCode());
        var futureFields=reviewFields(id);futureFields.put("date",day.plusDays(1).toString());assertEquals(400,browser.settings("/day-closeout/"+id,futureFields,true).statusCode());
        assertEquals(before,jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id));assertEquals(items,records.items(id));
        assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM booking_audit WHERE booking_id=?",Integer.class,id));assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM tycoon_award",Integer.class));
        for(var valid:List.of(day.minusDays(1),day)){
            long past=workBooking("Dozwolone wykonanie "+valid,valid);work.complete(past,0,"100","45","",Map.of(),Map.of(),List.of(),OWNER);
            var completed=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",past);
            assertThrows(IllegalArgumentException.class,()->records.reschedule(past,1,day.plusDays(1),java.time.LocalTime.NOON,"DONE"));
            assertEquals(completed,jdbc.queryForMap("SELECT * FROM booking WHERE id=?",past));
        }
    }

    @Test void explicitCloseoutIdNeverFallsBackToAnotherCustomer() throws Exception {
        var day=DashboardService.today();long today=workBooking("Właściwy klient",day),other=workBooking("Inny dzień",day.minusDays(1));var browser=app.browser();browser.login();
        assertEquals(404,browser.get("/day-closeout?date="+day+"&order=999999999").statusCode());
        assertEquals(404,browser.get("/day-closeout?date="+day+"&order="+other).statusCode());
        assertEquals(200,browser.get("/day-closeout?date="+day+"&order="+today).statusCode());
        var wrong=reviewFields(other);wrong.put("date",day.toString());assertEquals(400,browser.settings("/day-closeout/"+other,wrong,true).statusCode());
        app.context().getBean(pl.nclean.crm.records.CrmRecords.class).reschedule(today,0,day.plusDays(1),java.time.LocalTime.NOON,"PLANNED");
        assertEquals(404,browser.get("/day-closeout?date="+day+"&order="+today).statusCode());assertEquals(404,browser.get("/work/999999999").statusCode());assertEquals(404,browser.get("/customers/999999999").statusCode());
        assertEquals(404,browser.settings("/orders/999999999",Map.of("calendar","1","version","0","day",day,"starts","09:00","status","PLANNED"),true).statusCode());
    }

    @Test void sessionEndpointAndPublicThemeNeverExposePrivateData() throws Exception {
        var anonymous=app.browser();assertEquals(302,anonymous.get("/session").statusCode());
        assertEquals(200,anonymous.get("/login").statusCode());assertTrue(anonymous.get("/login").body().contains("/css/tycoon.css"));
        assertEquals(200,anonymous.get("/font/PixelifySans.ttf").statusCode());
        assertEquals(302,anonymous.get("/photos/00000000-0000-0000-0000-000000000001").statusCode());
        var owner=app.browser();owner.login();var session=owner.get("/session");assertEquals(200,session.statusCode());assertTrue(session.headers().firstValue("Cache-Control").orElse("").contains("no-store"));assertTrue(session.body().contains("token"));assertFalse(session.body().contains(PASSWORD));
        assertEquals(403,owner.settings("/customers",Map.of("name","Bez CSRF","phone","500000099"),false).statusCode());
    }

    @Test void pagesAndLookupAreBoundedWithoutLosingSingleRecordHistory() throws Exception {
        for(int n=0;n<62;n++)jdbc.update("INSERT INTO crm_customer(name,phone,address,active) VALUES (?,?,?,?)",String.format("Klient %03d",n),"+48500000099","Adres",n!=61);
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        assertEquals(26,records.customerPage("Klient",0,false).size());assertEquals(26,records.customerPage("Klient",1,false).size());assertEquals(12,records.customerPage("Klient",2,false).size());
        assertEquals(50,records.customerPage("Klient",0,true).size());assertThrows(IllegalArgumentException.class,()->records.customerPage("x",-1,false));
        var browser=app.browser();browser.login();assertEquals(200,browser.get("/customers?page=2").statusCode());assertTrue(browser.get("/customers").body().contains("Następne"));
        long id=workBooking("Stronicowanie nie gubi historii",DashboardService.today());assertEquals(200,browser.get("/orders").statusCode());assertEquals(200,browser.get("/orders?repeat="+id).statusCode());
    }

    @Test void ncleanekTracksAuthoritativeClosedAndReopenedDaysWithoutChangingRecords() throws Exception {
        var today=DashboardService.today();var yesterday=today.minusDays(1);long id=workBooking("Pomocnik",yesterday);
        var days=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);var guide=app.context().getBean(pl.nclean.crm.help.GuideService.class);
        assertEquals(yesterday,days.latestOpenBefore(today).orElseThrow().day());var before=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id);
        var browser=app.browser();browser.login();var response=browser.get("/help/context?date="+yesterday+"&order="+id);assertEquals(200,response.statusCode());assertTrue(response.body().contains("potwierdź"));assertEquals(before,jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id));
        var form=reviewFields(id);days.save(id,yesterday,form,OWNER);days.close(yesterday,days.review(yesterday).fingerprint(),OWNER);assertTrue(days.latestOpenBefore(today).isEmpty());assertFalse(guide.context(yesterday,id).containsKey("reminder"));
        jdbc.update("UPDATE booking SET version=version+1 WHERE id=?",id);assertEquals(yesterday,days.latestOpenBefore(today).orElseThrow().day());assertTrue(guide.context(yesterday,id).containsKey("reminder"));assertEquals(404,browser.get("/help/context?date="+today+"&order="+id).statusCode());
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);assertEquals(yesterday,app.context().getBean(pl.nclean.crm.work.DayReviewService.class).latestOpenBefore(today).orElseThrow().day());
    }

    @Test void historicalEntryKeepsUnknownContactAndMeasurementsAndPhotosAfterRestart() throws Exception {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        var day=DashboardService.today().minusMonths(8);long service=estimateService("Dawna kanapa");
        var token=UUID.randomUUID();
        long id=records.book(token,day,java.time.LocalTime.NOON,null,"","","",Map.of(service,BigDecimal.ONE),Map.of(),Map.of(),"UNKNOWN","","Archiwum",true);
        assertEquals(id,records.book(token,day,java.time.LocalTime.NOON,null,"","","",Map.of(service,BigDecimal.ONE),Map.of(),Map.of(),"UNKNOWN","","Archiwum",true));
        var row=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id);
        assertNull(row.get("customer_id"));assertEquals("Klient nieustalony",row.get("customer_name"));
        assertEquals("",row.get("phone"));assertEquals("DONE",row.get("status"));
        assertNull(row.get("final_total"));assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Integer.class));
        assertEquals(0,app.context().getBean(pl.nclean.crm.tycoon.AchievementService.class).performedCount());
        assertFalse(app.context().getBean(pl.nclean.crm.help.GuideService.class).context(DashboardService.today(),null).containsKey("reminder"));
        assertFalse(app.context().getBean(pl.nclean.crm.help.GuideService.class).context(day,id).containsKey("reminder"));
        var photos=app.context().getBean(pl.nclean.crm.context.ContextService.class);
        var image=photos.upload(id,"BEFORE",UUID.randomUUID(),serviceImage("stare-zdjecie.jpg"),OWNER,0);
        byte[] bytes=jdbc.queryForObject("SELECT image FROM booking_photo WHERE id=?",byte[].class,image);
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        assertArrayEquals(bytes,jdbc.queryForObject("SELECT image FROM booking_photo WHERE id=?",byte[].class,image));
        assertNull(jdbc.queryForObject("SELECT final_total FROM booking WHERE id=?",BigDecimal.class,id));
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM booking WHERE request_token=?",Integer.class,token));
        var browser=app.browser();browser.login();assertEquals(200,browser.get("/work/"+id).statusCode());
        assertTrue(browser.get("/work/"+id).body().contains("Wpis historyczny"));
    }

    @Test void addingHistoryToClosedOrdinaryDayDoesNotCreateAnOldReminder() {
        var day=DashboardService.today().minusDays(1);long ordinary=workBooking("Zamknięty dzień",day);
        var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);
        review.save(ordinary,day,reviewFields(ordinary),OWNER);review.close(day,review.review(day).fingerprint(),OWNER);
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long service=estimateService("Dopisane archiwum");
        long history=records.book(UUID.randomUUID(),day,java.time.LocalTime.NOON,null,"","","",Map.of(service,BigDecimal.ONE),Map.of(),Map.of(),"UNKNOWN","","",true);
        var guide=app.context().getBean(pl.nclean.crm.help.GuideService.class);
        assertFalse(guide.context(DashboardService.today(),null).containsKey("reminder"));
        assertFalse(guide.context(day,null).containsKey("reminder"));
        assertFalse(guide.context(day,history).containsKey("reminder"));
        jdbc.update("UPDATE booking SET completion_note='Rzeczywista korekta' WHERE id=?",ordinary);
        assertTrue(guide.context(DashboardService.today(),null).containsKey("reminder"));
    }

    @Test void historicalModeRejectsTodayAndDoesNotWeakenOrdinaryBookingValidation() {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);long service=estimateService("Walidacja historii");
        assertThrows(IllegalArgumentException.class,()->records.book(UUID.randomUUID(),DashboardService.today(),java.time.LocalTime.NOON,null,"","","",Map.of(service,BigDecimal.ONE),Map.of(),Map.of(),"UNKNOWN","","",true));
        assertThrows(IllegalArgumentException.class,()->records.book(UUID.randomUUID(),DashboardService.today(),java.time.LocalTime.NOON,null,"","","Adres",Map.of(service,BigDecimal.ONE)));
        assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM booking",Integer.class));
    }

    @Test void realServletPrefixKeepsPagesAssetsJsonSessionAndCsrfInsideCrm() throws Exception {
        long id=workBooking("Prefiks",DashboardService.today().minusDays(1));
        app.close();app=RunningApp.start(false,"/crm");jdbc=app.context().getBean(JdbcTemplate.class);
        var browser=app.browser();browser.login();
        for(String route:List.of("/calendar","/customers","/settings","/settings/areas","/settings/services","/dashboard","/fuel","/costs","/notes","/search","/callbacks","/work/"+id,"/day-closeout")){
            var response=browser.get(route);assertEquals(200,response.statusCode(),route);
            assertFalse(Pattern.compile("(?:href|src|action)=\"/(?!crm/)").matcher(response.body()).find(),route);
        }
        assertTrue(browser.get("/calendar").body().contains("content=\"/crm/\""));
        assertEquals(200,browser.get("/js/routes.js").statusCode());
        assertTrue(browser.get("/offline.html").body().contains("href=\"/crm/calendar\""));
        assertTrue(browser.get("/manifest.webmanifest").body().contains("\"scope\":\"./\""));
        var guide=browser.get("/help/context");assertEquals(200,guide.statusCode());
        assertTrue(guide.body().contains("/crm/day-closeout"));
        assertEquals(403,browser.settings("/customers",Map.of("name","Odrzucony","phone","500000099"),false).statusCode());
        assertEquals(200,browser.get("/session").statusCode());
    }

    @Test void customerProfileAndSourceAreOneAtomicCommand() {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);
        long id=records.saveCustomer(null,0,"Klient transakcyjny","500000076","Adres pierwotny","Historia",true);
        var before=jdbc.queryForMap("SELECT * FROM crm_customer WHERE id=?",id);
        assertThrows(IllegalArgumentException.class,()->records.saveCustomerProfile(
                new pl.nclean.crm.records.CustomerProfileCommand(id,0,"Zmiana","500000077","Nowy adres","",true,true,"INVALID","")));
        assertEquals(before,jdbc.queryForMap("SELECT * FROM crm_customer WHERE id=?",id));
        assertThrows(IllegalArgumentException.class,()->records.saveCustomerProfile(
                new pl.nclean.crm.records.CustomerProfileCommand(null,0,"Nowy klient","500000078","Adres","",true,true,"REFERRAL","x".repeat(201))));
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM crm_customer",Integer.class));
        records.saveCustomerProfile(new pl.nclean.crm.records.CustomerProfileCommand(id,0,"Klient poprawiony","500000077","Nowy adres","Historia",true,true,"REFERRAL","Od Anny"));
        assertEquals("REFERRAL",jdbc.queryForObject("SELECT source FROM crm_customer WHERE id=?",String.class,id));
        assertEquals("Od Anny",jdbc.queryForObject("SELECT referral_note FROM crm_customer WHERE id=?",String.class,id));
        records.saveCustomerProfile(new pl.nclean.crm.records.CustomerProfileCommand(id,1,"Klient poprawiony","500000077","Adres wizyty","Historia",true,false,null,null));
        assertEquals("Od Anny",jdbc.queryForObject("SELECT referral_note FROM crm_customer WHERE id=?",String.class,id));
        assertEquals(2L,jdbc.queryForObject("SELECT version FROM crm_customer WHERE id=?",Long.class,id));
    }

    @Test void removedBookingsStayOutOfCsvAndRestorationKeepsTheSnapshot() throws Exception {
        long id=workBooking("CSV pomyłka",DashboardService.today());
        var exports=app.context().getBean(pl.nclean.crm.work.ExportQueries.class);
        var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);
        var original=exports.orders();assertEquals(1,original.size());
        var browser=app.browser();browser.login();
        assertTrue(browser.get("/export/orders.csv").body().contains("Klient dnia"));
        remove.change("booking",id,0,false,OWNER);
        assertTrue(exports.orders().isEmpty());
        var csv=browser.get("/export/orders.csv");assertEquals(200,csv.statusCode());
        assertFalse(csv.body().contains("Klient dnia"));assertTrue(csv.body().contains("quoted_total"));
        remove.change("booking",id,1,true,OWNER);assertEquals(original,exports.orders());
        assertTrue(browser.get("/export/orders.csv").body().contains("Klient dnia"));
    }

    @Test void removalHandlersRequireTransactionAndAuditFailureRollsBackMutation() {
        long id=workBooking("Rollback audytu",DashboardService.today());
        var handler=app.context().getBean(pl.nclean.crm.work.BookingRemovalHandler.class);
        var command=new pl.nclean.crm.shared.removal.RemovalCommand("booking",id,0,false,OWNER);
        assertThrows(org.springframework.transaction.IllegalTransactionStateException.class,()->handler.change(command));
        var before=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id);
        jdbc.execute("ALTER TABLE removal_audit ADD CONSTRAINT audit_failure_probe CHECK (actor <> 'architecture-test-fail')");
        try {
            var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);
            assertThrows(org.springframework.dao.DataIntegrityViolationException.class,
                    ()->remove.change("booking",id,0,false,"architecture-test-fail"));
            assertEquals(before,jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id));
            assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM removal_audit",Integer.class));
            assertTrue(remove.change("booking",id,0,false,OWNER).removed());
            assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM removal_audit",Integer.class));
        } finally {
            jdbc.execute("ALTER TABLE removal_audit DROP CONSTRAINT audit_failure_probe");
        }
    }

    @Test void typedRemovalContractKeepsHttpFieldsAndNotFoundStatus() throws Exception {
        var day=DashboardService.today();long id=workBooking("Kontrakt usuwania",day);
        var browser=app.browser();browser.login();
        var form=new LinkedHashMap<String,Object>(Map.of("kind","booking","id",id,"version",0,"confirmed",true));
        var response=browser.settings("/manage/remove",form,true);assertEquals(200,response.statusCode());
        var json=new com.fasterxml.jackson.databind.ObjectMapper().readTree(response.body());
        assertTrue(json.get("saved").asBoolean());assertTrue(json.get("removed").asBoolean());
        assertEquals(id,json.get("id").asLong());assertEquals(1,json.get("version").asLong());
        assertEquals(day.toString(),json.get("day").asText());assertEquals("booking",json.get("kind").asText());
        assertEquals(response.body(),browser.settings("/manage/remove",form,true).body());
        form.put("id",Long.MAX_VALUE);assertEquals(404,browser.settings("/manage/remove",form,true).statusCode());
        form.put("kind","not_registered");assertEquals(400,browser.settings("/manage/remove",form,true).statusCode());
    }

    @Test void removedBookingIsExcludedEverywhereAndRestoresSnapshotsAfterRestart() throws Exception {
        var day=DashboardService.today();long id=workBooking("Usunięcie pomyłki",day);
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);
        var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var review=app.context().getBean(pl.nclean.crm.work.DayReviewService.class);
        work.complete(id,0,"180","45","Notatka historyczna",Map.of(),Map.of(),List.of(),OWNER);
        var items=jdbc.queryForList("SELECT * FROM booking_item WHERE booking_id=?",id);var snapshot=jdbc.queryForMap("SELECT * FROM booking WHERE id=?",id);
        assertEquals(new BigDecimal("180.00"),work.revenue(day,day,"actual"));
        assertEquals(2L,remove.change("booking",id,1,false,OWNER).version());
        remove.change("booking",id,1,false,OWNER);assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM removal_audit WHERE kind='booking' AND entity_id=?",Integer.class,id));
        assertTrue(records.monthBookings(YearMonth.from(day)).isEmpty());assertTrue(records.bookings(day,null).isEmpty());assertTrue(work.orders(day).isEmpty());assertTrue(work.analytics(day,day).isEmpty());assertTrue(review.review(day).orders().isEmpty());
        assertEquals(0,work.revenue(day,day,"actual").signum());assertTrue(app.context().getBean(pl.nclean.crm.dashboard.DashboardService.class).summary(day,"day","actual").orders().isEmpty());
        assertTrue(app.context().getBean(pl.nclean.crm.context.ContextService.class).search("500000098").stream().noneMatch(r->r.type().equals("order")));
        assertFalse(app.context().getBean(pl.nclean.crm.help.GuideService.class).context(day,null).containsKey("reminder"));
        assertThrows(org.springframework.web.server.ResponseStatusException.class,()->work.complete(id,2,"180","45","",Map.of(),Map.of(),List.of(),OWNER));
        assertThrows(IllegalStateException.class,()->remove.change("booking",id,0,true,OWNER));
        assertEquals(items,jdbc.queryForList("SELECT * FROM booking_item WHERE booking_id=?",id));
        assertThrows(IllegalArgumentException.class,()->records.book((UUID)snapshot.get("request_token"),day,java.time.LocalTime.NOON,null,"Ponowienie","500000098","Adres",Map.of(((Number)items.get(0).get("service_id")).longValue(),BigDecimal.ONE)));
        assertEquals(1,jdbc.queryForObject("SELECT count(*) FROM booking",Integer.class));
        app.close();app=RunningApp.start();jdbc=app.context().getBean(JdbcTemplate.class);
        assertTrue(app.context().getBean(pl.nclean.crm.records.CrmRecords.class).monthBookings(YearMonth.from(day)).isEmpty());
        app.context().getBean(pl.nclean.crm.removal.RemovalService.class).change("booking",id,2,true,OWNER);
        var restored=app.context().getBean(pl.nclean.crm.work.WorkService.class).order(id);assertEquals(snapshot.get("final_total"),restored.get("final_total"));assertEquals(snapshot.get("completion_note"),restored.get("completion_note"));assertEquals(items,jdbc.queryForList("SELECT * FROM booking_item WHERE booking_id=?",id));assertEquals(1,app.context().getBean(pl.nclean.crm.work.WorkService.class).orders(day).size());
    }

    @Test void removalRequiresConfirmationOwnerCsrfCurrentVersionAndCorrectedPayments() throws Exception {
        var day=DashboardService.today();long id=workBooking("Ochrona usuwania",day);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);
        var browser=app.browser();browser.login();var form=new LinkedHashMap<String,Object>(Map.of("kind","booking","id",id,"version",0,"confirmed",true));
        assertEquals(403,browser.settings("/manage/remove",form,false).statusCode());form.put("confirmed",false);assertEquals(400,browser.settings("/manage/remove",form,true).statusCode());form.put("confirmed",true);
        long paid=work.pay(id,UUID.randomUUID(),day,"50","CASH","");assertEquals(400,browser.settings("/manage/remove",form,true).statusCode());
        work.reverse(id,paid,UUID.randomUUID(),day,"Błędny wpis");work.timer(id,0,true,OWNER);form.put("version",1);assertEquals(400,browser.settings("/manage/remove",form,true).statusCode());work.timer(id,1,false,OWNER);
        form.put("version",0);assertEquals(409,browser.settings("/manage/remove",form,true).statusCode());form.put("version",2);assertEquals(200,browser.settings("/manage/remove",form,true).statusCode());assertEquals(2,jdbc.queryForObject("SELECT count(*) FROM booking_payment WHERE booking_id=?",Integer.class,id));assertEquals(404,browser.get("/work/"+id).statusCode());
        assertThrows(IllegalArgumentException.class,()->remove.change("not_a_table",id,3,false,OWNER));
    }

    @Test void removedCataloguePreservesBookedPricesAndCategoryServiceActivity() {
        var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);
        records.category(null,"ZZZ Kategoria usuwania");long category=jdbc.queryForObject("SELECT max(id) FROM service_category",Long.class);
        records.service(null,0,category,"ZZZ Usługa próbna","szt.","123",45,true);long service=jdbc.queryForObject("SELECT max(id) FROM service_definition",Long.class);
        long id=records.book(UUID.randomUUID(),DashboardService.today(),java.time.LocalTime.NOON,null,"Klient testowy","500000099","Adres testowy",Map.of(service,BigDecimal.ONE));var snapshot=records.items(id);
        remove.change("service",service,0,false,OWNER);assertTrue(records.services().stream().noneMatch(s->s.get("id").equals(service)));assertEquals(snapshot,records.items(id));
        assertThrows(IllegalArgumentException.class,()->records.book(UUID.randomUUID(),DashboardService.today(),java.time.LocalTime.NOON,null,"Nowy","500000099","Adres",Map.of(service,BigDecimal.ONE)));
        remove.change("category",category,0,false,OWNER);assertTrue(records.categories().stream().noneMatch(c->c.get("id").equals(category)));assertThrows(IllegalArgumentException.class,()->remove.change("service",service,1,true,OWNER));
        remove.change("category",category,1,true,OWNER);remove.change("service",service,1,true,OWNER);assertEquals(Boolean.TRUE,jdbc.queryForObject("SELECT active FROM service_definition WHERE id=?",Boolean.class,service));assertEquals(snapshot,records.items(id));
        assertEquals(0,jdbc.queryForObject("SELECT count(*) FROM booking_item WHERE booking_id=? AND price<>123",Integer.class,id));
    }

    @Test void chemicalRemovalBlocksActiveReferencesAndRestoresUnusedMaterial() {
        var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);
        long material=chemistry.saveMaterial(null,0,"Środek testowy","ml","1000","50");long service=estimateService("Powiązanie środka");chemistry.saveRecipe(service,0,true,Map.of(material,new BigDecimal("10")));
        assertThrows(IllegalArgumentException.class,()->remove.change("chemical",material,0,false,OWNER));
        chemistry.saveRecipe(service,1,true,Map.of());remove.change("chemical",material,0,false,OWNER);assertTrue(chemistry.materials().isEmpty());remove.change("chemical",material,1,true,OWNER);assertEquals("Środek testowy",chemistry.materials().get(0).name());
    }

    @Test void archivedChemicalRemainsEditableInItsHistoricalVisitWithSnapshotPrice() throws Exception {
        var chemistry=app.context().getBean(pl.nclean.crm.records.ChemistryService.class);var records=app.context().getBean(pl.nclean.crm.records.CrmRecords.class);var actual=app.context().getBean(pl.nclean.crm.records.ActualUsageService.class);var work=app.context().getBean(pl.nclean.crm.work.WorkService.class);var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);
        long material=chemistry.saveMaterial(null,0,"Historyczny środek","ml","1000","50");long service=estimateService("Historia usuniętej chemii");long id=records.book(UUID.randomUUID(),DashboardService.today(),java.time.LocalTime.NOON,null,"Klient testowy","500000099","Adres",Map.of(service,BigDecimal.ONE),Map.of(),Map.of(service,new pl.nclean.crm.records.ChemistryService.Forecast(true,Map.of(material,new BigDecimal("10")))));
        work.complete(id,0,"100","30","",Map.of(),Map.of(),List.of(),OWNER);actual.record(id,0,0,Map.of(material,new BigDecimal("8")));var before=records.actuals(id);remove.change("chemical",material,0,false,OWNER);assertTrue(chemistry.materials().isEmpty());assertEquals(material,chemistry.materialsForBooking(id).get(0).id());actual.record(id,0,1,Map.of(material,new BigDecimal("8")));var after=records.actuals(id);before.forEach(row->row.remove("recorded_at"));after.forEach(row->row.remove("recorded_at"));assertEquals(before,after);var browser=app.browser();browser.login();assertTrue(browser.get("/work/"+id).body().contains("Historyczny środek"));
    }

    @Test void expensesAndFuelRemoveAndRestoreOnceWithoutLosingHistory() {
        var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);var fuel=app.context().getBean(pl.nclean.crm.fuel.FuelJournalService.class);var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);var today=DashboardService.today();
        long expense=costs.save(expense("CAR_REPAIR","Błędny rachunek","120"),OWNER);
        long purchase=fuel.savePurchase(new pl.nclean.crm.fuel.FuelJournalService.Purchase(null,0,UUID.randomUUID(),java.time.LocalDateTime.now(java.time.ZoneId.of("Europe/Warsaw")).minusMinutes(1),"SHARED","DIESEL","50","10","5",false,null,false,"",null),OWNER);
        var before=costs.totals(today,today);assertEquals(new BigDecimal("170.00"),before.get("all"));
        remove.change("expense",expense,0,false,OWNER);remove.change("fuel",purchase,0,false,OWNER);assertEquals(0,costs.totals(today,today).get("all").signum());assertEquals(2,costs.entries(today,today,"all","",true,0).size());
        remove.change("expense",expense,1,true,OWNER);remove.change("fuel",purchase,1,true,OWNER);remove.change("fuel",purchase,1,true,OWNER);assertEquals(before,costs.totals(today,today));assertEquals(2,jdbc.queryForObject("SELECT count(*) FROM removal_audit WHERE kind='fuel' AND entity_id=?",Integer.class,purchase));
    }

    @Test void equipmentArchiveKeepsItsPurchaseAndInvestmentTotals() {
        var costs=app.context().getBean(pl.nclean.crm.costs.CostService.class);var remove=app.context().getBean(pl.nclean.crm.removal.RemovalService.class);var p=expense("EQUIPMENT_PURCHASE","Sprzęt próbny","1500");long expense=costs.save(p,OWNER);long asset=((Number)costs.entry(expense).get("asset_id")).longValue();var before=costs.entry(expense);var totals=costs.totals(DashboardService.today(),DashboardService.today());remove.change("equipment",asset,0,false,OWNER);assertEquals(Boolean.FALSE,costs.asset(asset).get("active"));assertEquals(before,costs.entry(expense));assertEquals(totals,costs.totals(DashboardService.today(),DashboardService.today()));remove.change("equipment",asset,1,true,OWNER);assertEquals(Boolean.TRUE,costs.asset(asset).get("active"));
    }

    @Test void v15KeepsV14ClosedDayFingerprintAndAllSnapshots() throws Exception {
        String schema="legacy_v14_closed_day";var source=new DriverManagerDataSource(POSTGRES.getJdbcUrl()+(POSTGRES.getJdbcUrl().contains("?")?"&":"?")+"currentSchema="+schema,POSTGRES.getUsername(),POSTGRES.getPassword());var old=new JdbcTemplate(source);
        Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).target("14").load().migrate();long person=old.queryForObject("INSERT INTO crm_customer(name,phone) VALUES ('Klient testowy','500000099') RETURNING id",Long.class);var day=DashboardService.today().minusDays(1);
        old.update("INSERT INTO booking(request_token,customer_id,day,starts,customer_name,phone,address,status,total) VALUES (?,?,?,TIME '10:00','Klient testowy','500000099','Adres testowy','CANCELLED',100)",UUID.randomUUID(),person,day);
        var field=pl.nclean.crm.work.DayReviewService.class.getDeclaredField("FINGERPRINT_SQL");field.setAccessible(true);String current=(String)field.get(null),legacy=current.replace("b.removed_at IS NULL AND ","").replace("removed_at IS NULL AND ","").replace("to_jsonb(b)-'removed_at'-'historical'","to_jsonb(b)");String fingerprint=old.queryForObject(legacy,String.class,day,day,day,day,day);
        old.update("INSERT INTO day_review(day,fingerprint,closed_by) VALUES (?,?,?)",day,fingerprint,OWNER);Flyway.configure().dataSource(source).schemas(schema).defaultSchema(schema).load().migrate();assertEquals(fingerprint,old.queryForObject(current,String.class,day,day,day,day,day));assertEquals(fingerprint,old.queryForObject("SELECT fingerprint FROM day_review",String.class));assertEquals(0,old.queryForObject("SELECT count(*) FROM booking WHERE removed_at IS NOT NULL",Integer.class));
    }

    private static final class Browser {
        private final URI base;
        private final HttpClient http;

        Browser(URI base) {
            this.base = base;
            http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10))
                .followRedirects(HttpClient.Redirect.NEVER)
                .cookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ALL)).build();
        }

        HttpResponse<String> get(String path) throws IOException, InterruptedException {
            return http.send(HttpRequest.newBuilder(base.resolve(base.getPath()+path)).timeout(Duration.ofSeconds(15)).GET().build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        }

        HttpResponse<String> post(String path, Map<String, ?> form) throws IOException, InterruptedException {
            var pairs = new ArrayList<String>();
            form.forEach((name, value) -> {
                if (value instanceof Iterable<?> values) values.forEach(item -> pairs.add(encode(name) + "=" + encode(item.toString())));
                else pairs.add(encode(name) + "=" + encode(value.toString()));
            });
            String body = String.join("&", pairs);
            return http.send(HttpRequest.newBuilder(base.resolve(base.getPath()+path)).timeout(Duration.ofSeconds(15))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build(),
                HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        }

        void login() throws IOException, InterruptedException {
            var page = get("/login");
            assertEquals(200, page.statusCode());
            var response = post("/login", Map.of("username", OWNER, "password", PASSWORD, "_csrf", csrf(page.body())));
            assertEquals(302, response.statusCode());
            assertFalse(response.headers().firstValue("Location").orElseThrow().contains("error"));
            assertEquals(200, get("/calendar?month=2026-10").statusCode());
        }

        HttpResponse<String> assign(String day, List<Long> areaIds, boolean includeCsrf) throws IOException, InterruptedException {
            var fields = new LinkedHashMap<String, Object>(); fields.put("date", day);
            if (!areaIds.isEmpty()) fields.put("districtIds", areaIds);
            return settings("/calendar/areas", fields, includeCsrf);
        }

        HttpResponse<String> settings(String path, Map<String, ?> fields, boolean includeCsrf) throws IOException, InterruptedException {
            var form = new LinkedHashMap<String, Object>(fields);
            if (includeCsrf) {
                var page = get(calendarPath(DAY)); assertEquals(200, page.statusCode());
                form.put("_csrf", csrf(page.body()));
            }
            return post(path, form);
        }

        private static String csrf(String html) {
            var matcher = Pattern.compile("<input[^>]*name=\"_csrf\"[^>]*value=\"([^\"]+)\"").matcher(html);
            assertTrue(matcher.find(), "The real login/calendar form must include its CSRF token");
            return matcher.group(1);
        }

        private static String encode(String value) { return URLEncoder.encode(value, StandardCharsets.UTF_8); }
    }
}
