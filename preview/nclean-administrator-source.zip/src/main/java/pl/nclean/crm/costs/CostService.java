package pl.nclean.crm.costs;

import pl.nclean.crm.shared.DecimalInput;
import pl.nclean.crm.shared.BusinessDates;
import java.math.*;
import java.time.*;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly=true)
public class CostService {
    public static final Map<String,String> CATEGORIES;
    static{var m=new LinkedHashMap<String,String>();m.put("CAR_REPAIR","Samochód — naprawa");m.put("CAR_SERVICE","Samochód — serwis / przegląd");m.put("CAR_PARTS","Samochód — części / akcesoria");m.put("CAR_OTHER","Samochód — ubezpieczenie / inne");m.put("EQUIPMENT_PURCHASE","Zakup sprzętu");m.put("EQUIPMENT_SERVICE","Serwis sprzętu");m.put("MATERIAL","Materiały eksploatacyjne");m.put("CHEMISTRY","Zakup chemii");m.put("MARKETING","Marketing jednorazowy");m.put("OTHER","Inny wydatek");CATEGORIES=Collections.unmodifiableMap(m);}
    private final JdbcTemplate db;
    public CostService(JdbcTemplate db){this.db=db;}
    private void lock(){db.queryForObject("SELECT id FROM fuel_write_guard WHERE id=1 FOR UPDATE",Integer.class);}
    private static String text(Map<String,String> p,String key,int max,boolean required){String v=p.getOrDefault(key,"").strip();if(v.length()>max||required&&v.isBlank())throw new IllegalArgumentException("Sprawdź opis i długość pól.");return v;}
    private static Long id(Map<String,String> p,String key){String v=p.get(key);return v==null||v.isBlank()?null:Long.valueOf(v);}
    private static BigDecimal number(String s,int scale,String max,boolean optional){return DecimalInput.parse(s,scale,new BigDecimal(max),optional);}
    private static LocalDate date(String value,boolean required){if(value==null||value.isBlank()){if(required)throw new IllegalArgumentException("Wybierz datę.");return null;}var day=LocalDate.parse(value);BusinessDates.period(day,"day");return day;}
    public Map<String,Object> entry(long id){return db.queryForList("SELECT * FROM cost_entry WHERE id=?",id).stream().findFirst().orElseThrow(()->new IllegalArgumentException("Nieznany wydatek."));}
    public Map<String,Object> asset(long id){return db.queryForList("SELECT * FROM equipment_item WHERE id=?",id).stream().findFirst().orElseThrow(()->new IllegalArgumentException("Nieznany sprzęt."));}
    public List<Map<String,Object>> assets(){return db.queryForList("SELECT a.*,COALESCE((SELECT SUM(amount) FROM cost_entry e WHERE e.asset_id=a.id AND NOT e.cancelled AND e.effect='INVESTMENT'),0) purchase_total,COALESCE((SELECT SUM(amount) FROM cost_entry e WHERE e.asset_id=a.id AND NOT e.cancelled AND e.category<>'EQUIPMENT_PURCHASE'),0) maintenance_total FROM equipment_item a ORDER BY active DESC,name,id");}
    public List<Map<String,Object>> assetHistory(long id){return db.queryForList("SELECT * FROM cost_entry WHERE asset_id=? ORDER BY spent_on DESC,id DESC",id);}
    public BigDecimal operating(LocalDate start,LocalDate end){return db.queryForObject("SELECT COALESCE(SUM(amount),0) FROM cost_entry WHERE spent_on BETWEEN ? AND ? AND effect='OPERATING' AND NOT cancelled",BigDecimal.class,start,end);}
    public BigDecimal operatingMarketing(LocalDate start,LocalDate end){return db.queryForObject("SELECT COALESCE(SUM(amount),0) FROM cost_entry WHERE spent_on BETWEEN ? AND ? AND effect='OPERATING' AND category='MARKETING' AND NOT cancelled",BigDecimal.class,start,end);}
    public BigDecimal investments(LocalDate start,LocalDate end){return db.queryForObject("SELECT COALESCE(SUM(amount),0) FROM cost_entry WHERE spent_on BETWEEN ? AND ? AND effect='INVESTMENT' AND NOT cancelled",BigDecimal.class,start,end);}
    public Map<String,BigDecimal> totals(LocalDate start,LocalDate end){
        var result=new LinkedHashMap<String,BigDecimal>();for(String key:List.of("fuel","carFuel","carOther","chemistry","investments","operating","covered","all"))result.put(key,BigDecimal.ZERO);
        result.put("fuel",db.queryForObject("SELECT COALESCE(SUM(amount),0) FROM fuel_purchase WHERE purchased_at>=? AND purchased_at<? AND NOT cancelled",BigDecimal.class,start.atStartOfDay(),end.plusDays(1).atStartOfDay()));
        result.put("carFuel",db.queryForObject("SELECT COALESCE(SUM(amount),0) FROM fuel_purchase WHERE purchased_at>=? AND purchased_at<? AND target='CAR' AND NOT cancelled",BigDecimal.class,start.atStartOfDay(),end.plusDays(1).atStartOfDay()));
        for(var row:db.queryForList("SELECT category,effect,SUM(amount) amount FROM cost_entry WHERE spent_on BETWEEN ? AND ? AND NOT cancelled GROUP BY category,effect",start,end)){
            var amount=(BigDecimal)row.get("amount");String category=(String)row.get("category"),effect=(String)row.get("effect");result.put("all",result.get("all").add(amount));if(category.startsWith("CAR_"))result.put("carOther",result.get("carOther").add(amount));if(category.equals("CHEMISTRY"))result.put("chemistry",result.get("chemistry").add(amount));String key=switch(effect){case "INVESTMENT"->"investments";case "COVERED"->"covered";case "OPERATING"->"operating";default->null;};if(key!=null)result.put(key,result.get(key).add(amount));
        }
        result.put("all",result.get("all").add(result.get("fuel")));return result;
    }
    private static final String UNION="""
        SELECT 'EXPENSE' source,id,version,spent_on,category,title,amount,supplier,note,odometer,receipt_id,cancelled,cancel_reason,asset_id,quantity,effect,covered_month,covered_category,chemical_id FROM cost_entry
        UNION ALL SELECT 'FUEL',id,version,purchased_at::date,'FUEL','Tankowanie — '||CASE target WHEN 'CAR' THEN 'samochód' WHEN 'GENERATOR' THEN 'agregat' ELSE 'wspólny zapas' END,amount,'',note,odometer,receipt_id,cancelled,cancel_reason,NULL::bigint,litres,'PURCHASE_ONLY',NULL::date,NULL::varchar,NULL::bigint FROM fuel_purchase
        """;
    public List<Map<String,Object>> entries(LocalDate start,LocalDate end,String view,String query,boolean cancelled,int page){
        if(!Set.of("overview","car","equipment","chemistry","fixed","all").contains(view)||query==null||query.length()>120||page<0||page>200000)throw new IllegalArgumentException("Sprawdź filtr i wyszukiwanie.");
        String filter=switch(view){case "car"->" AND (category LIKE 'CAR_%' OR (source='FUEL' AND title='Tankowanie — samochód'))";case "equipment"->" AND (category IN ('EQUIPMENT_PURCHASE','EQUIPMENT_SERVICE','MATERIAL'))";case "chemistry"->" AND category='CHEMISTRY'";case "fixed"->" AND (category='MARKETING' OR effect='COVERED')";default->"";};
        var rows=db.queryForList("SELECT * FROM ("+UNION+") e WHERE spent_on BETWEEN ? AND ? AND (? OR NOT cancelled) AND (position(lower(?) in lower(title||' '||supplier||' '||note))>0)"+filter+" ORDER BY spent_on DESC,id DESC,source LIMIT 51 OFFSET ?",start,end,cancelled,query.strip(),page*50);return rows;
    }
    public List<Map<String,Object>> usage(LocalDate start,LocalDate end){return db.queryForList("SELECT a.*,b.day,b.customer_name,i.name service_name,i.actual_no_chem FROM booking_actual_chemical a JOIN booking b ON b.id=a.booking_id JOIN booking_item i ON i.booking_id=a.booking_id AND i.position=a.item_position WHERE b.removed_at IS NULL AND b.status='DONE' AND i.actual_defined AND NOT i.actual_no_chem AND b.day BETWEEN ? AND ? ORDER BY b.day DESC,b.id,i.position,a.chemical_id LIMIT 200",start,end);}
    public List<Map<String,Object>> zeroUsage(LocalDate start,LocalDate end){return db.queryForList("SELECT b.id,b.day,b.customer_name,i.name FROM booking_item i JOIN booking b ON b.id=i.booking_id WHERE b.removed_at IS NULL AND b.status='DONE' AND i.actual_no_chem AND b.day BETWEEN ? AND ? ORDER BY b.day DESC LIMIT 200",start,end);}
    @Transactional public void checkMonthCategories(YearMonth month,Set<String> proposed){lock();for(String used:db.queryForList("SELECT DISTINCT covered_category FROM cost_entry WHERE covered_month=? AND NOT cancelled",String.class,month.atDay(1)))if(!proposed.contains(used))throw new IllegalArgumentException("Ten rodzaj kosztu miesięcznego ma przypisany rachunek. Najpierw zmień powiązanie lub anuluj rachunek w Kosztach i inwestycjach.");}
    @Transactional public long save(Map<String,String> p,String actor){
        String category=p.get("category");if(!CATEGORIES.containsKey(Objects.toString(category,"")))throw new IllegalArgumentException("Wybierz rodzaj wydatku. Paliwo zapisuj w istniejącym formularzu tankowania.");
        var day=date(p.get("spent_on"),true);if(day.isAfter(BusinessDates.today()))throw new IllegalArgumentException("Zakup lub rachunek zapisz najwcześniej w dniu zdarzenia.");String title=text(p,"title",160,true),supplier=text(p,"supplier",160,false),note=text(p,"note",2000,false);
        BigDecimal amount=number(p.get("amount"),2,"9999999999.99",false),quantity=number(p.get("quantity"),3,"99999999999.999",true),odo=number(p.get("odometer"),1,"999999999.9",true);
        if(quantity!=null&&quantity.signum()==0)throw new IllegalArgumentException("Ilość musi być dodatnia lub pusta.");if(odo!=null&&!category.startsWith("CAR_"))throw new IllegalArgumentException("Przebieg w tym formularzu dotyczy samochodu.");
        Long id=id(p,"id"),asset=id(p,"asset_id"),chemical=id(p,"chemical_id");long version=Long.parseLong(p.getOrDefault("version","0"));UUID token=UUID.fromString(Objects.toString(p.get("token"),""));UUID receipt=p.getOrDefault("receipt_id","").isBlank()?null:UUID.fromString(p.get("receipt_id"));
        String effect=category.equals("EQUIPMENT_PURCHASE")?"INVESTMENT":category.equals("CHEMISTRY")?"PURCHASE_ONLY":"OPERATING";LocalDate month=null;String covered=null;
        if(p.containsKey("covered")){if(!effect.equals("OPERATING"))throw new IllegalArgumentException("Ten zakup nie jest kosztem miesięcznym.");month=YearMonth.parse(p.get("covered_month")).atDay(1);BusinessDates.period(month,"day");covered=text(p,"covered_category",20,true);effect="COVERED";}
        lock();if(id==null){var replay=db.queryForList("SELECT id FROM cost_entry WHERE request_token=?",Long.class,token);if(!replay.isEmpty())return replay.get(0);}
        var old=id==null?null:entry(id);if(old!=null&&(((Number)old.get("version")).longValue()!=version||(Boolean)old.get("cancelled")))throw new IllegalArgumentException("Wpis zmienił się lub jest anulowany. Zachowaj pola i sprawdź aktualny stan.");
        if(month!=null&&db.queryForObject("SELECT count(*) FROM dashboard_month m JOIN dashboard_month_cost c ON c.month=m.month WHERE m.month=? AND m.configured AND c.category=?",Integer.class,month,covered)==0)throw new IllegalArgumentException("Wybierz skonfigurowany koszt miesięczny tego rodzaju. Nie tworzymy drugiego kosztu.");
        String chemicalName=null;if(category.equals("CHEMISTRY")){if(chemical==null)throw new IllegalArgumentException("Wybierz środek z katalogu.");chemicalName=db.queryForList("SELECT name FROM chemical WHERE id=?",String.class,chemical).stream().findFirst().orElseThrow(()->new IllegalArgumentException("Nieznany środek."));}else if(chemical!=null)throw new IllegalArgumentException("Środek dotyczy zakupu chemii.");
        if(old!=null&&category.equals("EQUIPMENT_PURCHASE")&&!p.containsKey("asset_id"))asset=(Long)old.get("asset_id");
        boolean equipment=category.equals("EQUIPMENT_PURCHASE")||category.equals("EQUIPMENT_SERVICE")||category.equals("MATERIAL");if(asset!=null&&!equipment)throw new IllegalArgumentException("Sprzęt dotyczy zakupu, serwisu lub materiałów eksploatacyjnych.");
        if(asset!=null){var a=asset(asset);if(!(Boolean)a.get("active")&&(old==null||!Objects.equals(old.get("asset_id"),asset)))throw new IllegalArgumentException("Wybierz aktywny sprzęt; historia nieaktywnego pozostaje zachowana.");}
        if(category.equals("EQUIPMENT_PURCHASE")){if(quantity==null)quantity=BigDecimal.ONE;if(asset==null){asset=db.queryForObject("INSERT INTO equipment_item(request_token,name,category,model,serial_number,warranty_until,supplier,note) VALUES (?,?,?,?,?,?,?,?) RETURNING id",Long.class,old==null?token:UUID.randomUUID(),title,p.getOrDefault("asset_category","").isBlank()?"Sprzęt":text(p,"asset_category",100,false),text(p,"model",160,false),text(p,"serial_number",160,false),date(p.get("warranty_until"),false),supplier,note);}}
        if(category.equals("EQUIPMENT_SERVICE")&&asset==null)throw new IllegalArgumentException("Wybierz sprzęt, którego dotyczy serwis.");
        if(receipt!=null){if(db.queryForObject("SELECT count(*) FROM fuel_receipt WHERE id=?",Integer.class,receipt)!=1)throw new IllegalArgumentException("Zdjęcie nie istnieje lub wygasło. Dodaj je ponownie.");if(db.queryForObject("SELECT (SELECT count(*) FROM fuel_purchase WHERE receipt_id=?)+(SELECT count(*) FROM cost_entry WHERE receipt_id=? AND id<>?)",Integer.class,receipt,receipt,id==null?-1:id)>0)throw new IllegalArgumentException("Rachunek jest już powiązany z innym wpisem.");}
        String before=old==null?null:db.queryForObject("SELECT to_jsonb(e)::text FROM cost_entry e WHERE id=?",String.class,id);
        if(old==null)id=db.queryForObject("INSERT INTO cost_entry(request_token,spent_on,category,title,amount,effect,quantity,supplier,note,odometer,asset_id,chemical_id,chemical_name,covered_month,covered_category,receipt_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING id",Long.class,token,day,category,title,amount,effect,quantity,supplier,note,odo,asset,chemical,chemicalName,month,covered,receipt);
        else changed(db.update("UPDATE cost_entry SET spent_on=?,category=?,title=?,amount=?,effect=?,quantity=?,supplier=?,note=?,odometer=?,asset_id=?,chemical_id=?,chemical_name=?,covered_month=?,covered_category=?,receipt_id=?,version=version+1 WHERE id=? AND version=?",day,category,title,amount,effect,quantity,supplier,note,odo,asset,chemical,chemicalName,month,covered,receipt,id,version));
        audit(id,null,before,actor);return id;
    }
    @Transactional public void cancel(long id,long version,String reason,String actor){lock();var old=entry(id);if(((Number)old.get("version")).longValue()!=version||(Boolean)old.get("cancelled"))throw conflict();reason=reason==null?"":reason.strip();if(reason.isBlank()||reason.length()>300)throw new IllegalArgumentException("Podaj powód anulowania do 300 znaków.");String before=db.queryForObject("SELECT to_jsonb(e)::text FROM cost_entry e WHERE id=?",String.class,id);changed(db.update("UPDATE cost_entry SET cancelled=TRUE,cancel_reason=?,version=version+1 WHERE id=? AND version=?",reason,id,version));audit(id,null,before,actor);}
    @Transactional public void restore(long id,long version,String actor){
        lock();var old=entry(id);if(((Number)old.get("version")).longValue()!=version||!Boolean.TRUE.equals(old.get("cancelled")))throw conflict();
        if(old.get("covered_month")!=null&&db.queryForObject("SELECT count(*) FROM dashboard_month m JOIN dashboard_month_cost c ON c.month=m.month WHERE m.month=? AND m.configured AND c.category=?",Integer.class,old.get("covered_month"),old.get("covered_category"))==0)throw new IllegalArgumentException("Najpierw przywróć powiązany koszt miesięczny lub popraw powiązanie rachunku.");
        String before=db.queryForObject("SELECT to_jsonb(e)::text FROM cost_entry e WHERE id=?",String.class,id);changed(db.update("UPDATE cost_entry SET cancelled=FALSE,cancel_reason='',version=version+1 WHERE id=? AND version=?",id,version));audit(id,null,before,actor);
    }
    @Transactional public void editAsset(long id,long version,Map<String,String> p,String actor){lock();asset(id);String name=text(p,"name",160,true);var warranty=date(p.get("warranty_until"),false);String before=db.queryForObject("SELECT to_jsonb(a)::text FROM equipment_item a WHERE id=?",String.class,id);changed(db.update("UPDATE equipment_item SET name=?,category=?,model=?,serial_number=?,warranty_until=?,supplier=?,note=?,active=?,version=version+1 WHERE id=? AND version=?",name,text(p,"category",100,false),text(p,"model",160,false),text(p,"serial_number",160,false),warranty,text(p,"supplier",160,false),text(p,"note",2000,false),p.containsKey("active"),id,version));audit(null,id,before,actor);}
    public List<Map<String,Object>> audit(long id){return db.queryForList("SELECT created_at,actor,before_data->>'amount' old_amount,after_data->>'amount' amount,after_data->>'cancelled' cancelled FROM cost_audit WHERE entry_id=? ORDER BY id DESC LIMIT 30",id);}
    private void audit(Long id,Long asset,String before,String actor){db.update("INSERT INTO cost_audit(entry_id,asset_id,before_data,after_data,actor) SELECT ?,?,?::jsonb,to_jsonb(t),? FROM "+(id==null?"equipment_item":"cost_entry")+" t WHERE id=?",id,asset,before,actor,id==null?asset:id);}
    private static void changed(int n){if(n!=1)throw conflict();}private static IllegalArgumentException conflict(){return new IllegalArgumentException("Wpis zmienił się w innym oknie. Zachowano formularz — sprawdź aktualny stan.");}
}
