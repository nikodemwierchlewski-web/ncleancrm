# Podglad

Otworz [index.html](index.html). To DEMO bez bazy danych.
Instrukcja administratora: ../deploy/ops/RUNBOOK.md
Eksport cwiczenia JSON nie jest kopia PostgreSQL i nie obejmuje zdjec.
