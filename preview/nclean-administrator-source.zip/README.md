# ncLEAN CRM — wersja 0.1

Uporządkowany układ codziennej pracy: [Lean workspace — obsługa i weryfikacja](docs/LEAN-WORKSPACE.md). Nawigacja: Dzisiaj, Kalendarz, Klienci, Więcej. Kalendarz pozostaje ekranem startowym.

Kalendarz obsługuje logowanie właściciela, przypisanie wielu kolorowych obszarów pracy do dnia oraz ustawienia nazw, kolorów i aktywności obszarów. Na komputerze miesiąc ma układ 7 kolumn i stały panel dnia, a na telefonie kompaktowy pasek tygodnia i plan wybranego dnia. Formularz zachowuje usługi z kilku kategorii i podpowiada klienta w jednym polu. Zlecenia są widoczne bezpośrednio w kalendarzu; krótki formularz pozwala wybrać usługi z cennika i istniejącego lub nowego klienta. Przypisania są zapisywane w PostgreSQL i pozostają po restarcie aplikacji. To osobna aplikacja i baza, bez połączenia z produkcyjnym CMS nclean.pl.

Nowe opcje: tygodniowy plan obszarów z wyjątkami, ceny uzgadniane w rezerwacji oraz standardy i prognozy chemii. Instrukcja: [docs/PLAN-CENNIK-CHEMIA.md](docs/PLAN-CENNIK-CHEMIA.md). Wyniki sprawdzenia: [docs/WERYFIKACJA-PLANU-I-PROGNOZ.md](docs/WERYFIKACJA-PLANU-I-PROGNOZ.md).

Rzeczywiste ilości po wykonaniu zlecenia i propozycje standardów z mediany: [docs/RZECZYWISTE-ZUZYCIE-I-PROPOZYCJE.md](docs/RZECZYWISTE-ZUZYCIE-I-PROPOZYCJE.md).

Dashboard dnia, tygodnia i miesiąca, plan/wykonanie, paliwo i koszty miesięczne: [docs/DASHBOARD.md](docs/DASHBOARD.md).

Licznik samochodu, czas agregatu i tankowania ze zdjęciami: [docs/PALIWO-I-AGREGAT.md](docs/PALIWO-I-AGREGAT.md).

Wersja 0.1: [dzień pracy, wykonanie, wpłaty, analiza i PWA](docs/WERSJA-0.1.md), [wyniki weryfikacji](docs/WERYFIKACJA-0.1.md). Ekran startowy: Kalendarz.

Źródło klienta, notatki wizyt, zdjęcia przed/po z czasem, wyszukiwanie i ponowny kontakt: [docs/ZDJECIA-I-KONTAKT.md](docs/ZDJECIA-I-KONTAKT.md).

Opis dotychczasowej obsługi kalendarza: [docs/KALENDARZ.md](docs/KALENDARZ.md).

Stos: Java 17, Spring Boot 3.5.16, Spring MVC, Thymeleaf, Spring Security, PostgreSQL 17 i Flyway. JPA/Hibernate jest używane obok JdbcTemplate, który obsługuje większość modułów operacyjnych. Cennik i kategorie są edytowalne w PostgreSQL; początkowa oferta pochodzi z migracji SQL. Maven Wrapper pobiera Maven 3.9.11 i sprawdza jego SHA-256. Nie ma Reacta ani osobnej aplikacji SPA.

Aktualny cel wdrożenia: **https://nclean.pl/crm/**, bez subdomeny. [Audyt zgodności ścieżek](deploy/SAME-DOMAIN-AUDIT.md) i [plan wdrożenia](deploy/README.md). Obsługa adresów i izolacja PWA zostały poprawione i sprawdzone lokalnie pod `/crm/` z HTTPS oraz publicznym stubem strony. Odbiór rzeczywistego serwera nadal należy do administratora. [Aktualny audyt](docs/final-audit/REPORT.md), [instrukcja operacyjna](deploy/ops/RUNBOOK.md). Starszy audyt ogólny: [docs/AUDYT-GOTOWOSCI.md](docs/AUDYT-GOTOWOSCI.md).

Reakcje interfejsu na klikanie: [Cleaning Tycoon — interakcje](docs/TYCOON-INTERACTIONS.md).

Graficzny wygląd ncLEAN jest stały dla całej aplikacji. [Animacje, odznaki i postęp](docs/CLEANING-TYCOON-PROGRESS.md), [pobieralny podgląd DEMO](preview/README.md). Aktualna demonstracja symuluje zapis w pamięci, a prawdziwy CRM zapisuje dane w PostgreSQL.

## Architektura i dalsza rozbudowa

[Zasady modułów](docs/architecture/ARCHITECTURE.md), [audyt i wykonana refaktoryzacja](docs/architecture/AUDIT.md), [prompt etapu](docs/architecture/REFACTOR-PROMPT.md), [wkład w projekt](CONTRIBUTING.md).
Testy ArchUnit w zwykłym `mvnw test` i `verify` pilnują granic modułów.

## Windows — pierwsze uruchomienie

Zainstaluj JDK 17, ustaw `JAVA_HOME` i uruchom Docker Desktop z kontenerami Linux oraz Compose v2. W PowerShell, w katalogu repozytorium:

```powershell
.\scripts\Initialize-Local.ps1
.\scripts\Start-Local.ps1
```

Inicjalizator poprosi o własne hasło konta `local-owner`, wygeneruje hasła bazy i zapisze konfigurację tylko w ignorowanym katalogu `.local/`. Jawne hasło właściciela nie jest zapisywane; aplikacja otrzymuje hash BCrypt. Pliki nie są nadpisywane przy kolejnym uruchomieniu.

Po starcie otwórz http://127.0.0.1:8081 i zaloguj się. Pełna instrukcja, sprawdzenie zapisu po restarcie i rozwiązywanie problemów: [docs/WINDOWS.md](docs/WINDOWS.md). Skrypty PowerShell wymagają osobnej weryfikacji na rzeczywistym Windows; w tym środowisku sprawdzono inicjalizator Java, Compose i aplikację na Linux.

## Linux/macOS — pierwsze uruchomienie

Wymagane są JDK 17, ustawione `JAVA_HOME`, Docker i Compose v2. Z katalogu repozytorium, w interaktywnym terminalu:

```sh
./mvnw dependency:build-classpath -DincludeScope=runtime -Dmdep.outputFile=.local/runtime-classpath.txt
"${JAVA_HOME}/bin/java" -cp "$(cat .local/runtime-classpath.txt)" scripts/InitializeLocal.java
docker compose up -d --wait
./mvnw spring-boot:run -Dspring-boot.run.profiles=local '-Dspring-boot.run.arguments=--spring.datasource.url=jdbc:postgresql://127.0.0.1:55433/nclean_crm --spring.flyway.url=jdbc:postgresql://127.0.0.1:55433/nclean_crm'
```

Inicjalizator wymaga terminala, aby ukryć wpisywane hasło. Przy kolejnych uruchomieniach wystarczą dwa ostatnie polecenia.

## Lokalna baza i konfiguracja

- Compose uruchamia PostgreSQL wyłącznie pod `127.0.0.1:55433`, z nazwanym wolumenem `ncleancrm-local_postgres-data`.
- Aplikacja używa bazy `nclean_crm` i konta `crm_dev`, bez uprawnień superużytkownika, tworzenia baz i ról. Osobne konto `crm_bootstrap` służy do pierwszej inicjalizacji kontenera.
- Hasła bazy są przekazywane do Compose z lokalnych plików sekretów. Kontrola gotowości sprawdza rzeczywiste połączenie konta `crm_dev`, a nie tylko otwarty port.
- Profil `local` wymaga `.local/application-local.properties` i ustawia lokalny adres bazy. Nie kopiuj do tego środowiska poświadczeń CMS. Pliki `.env` nie są automatycznie wczytywane przez Spring; [env.example](env.example) dokumentuje zmienne dla ręcznej konfiguracji.
- Flyway uruchamia migracje V1–V16 przy pierwszym starcie. Niezmieniona V1 tworzy `district`, `day_district` i pięć przykładowych obszarów. V2 rozszerza klucz przypisań do pary dzień–obszar, zachowując dotychczasowe dane. V3 dodaje kartotekę, cennik i rezerwacje; V4 wersje tygodniowego planu i znaczniki wyjątków; V5 środki, standardy, ceny uzgodnione i prognozy. V6 dodaje osobne rzeczywiste pomiary, bez kopiowania prognoz. V7 dodaje koszty dashboardu i historyczne wyceny rzeczywistych pomiarów. V8 dodaje dziennik licznika/agregatu, tankowania, prywatne zdjęcia rachunków i audyt korekt. V9 dodaje wykonanie, cenę końcową, czas, audyt zlecenia i rejestr wpłat. V10 dodaje kontekst klienta i zdjęcia usług; V11 zamknięcie dnia; V12 notatki i cele; V13 książeczkę samochodu, sprzęt i koszty jednorazowe; V14 postęp i osiągnięcia; V15 odwracalne usuwanie i audyt; V16 jawne wpisy historyczne bez fikcyjnej kartoteki klienta. Istniejąca baza otrzymuje jedynie brakujące migracje. Hibernate waliduje schemat (`ddl-auto=validate`); Flyway `clean` jest wyłączony.
- Logowanie wymaga loginu oraz poprawnego hasha BCrypt. Operacje zapisu i wylogowania wymagają POST z CSRF; odczyt kalendarza wymaga roli OWNER.

Zatrzymanie aplikacji przez `Ctrl+C` zachowuje dane. `docker compose down` usuwa kontener, ale zachowuje wolumen; `docker compose up -d --wait` korzysta z zapisanej bazy. **`docker compose down -v` usuwa dane** — nie używaj go do zwykłego restartu. Nie usuwaj również plików `.local/`, jeśli chcesz dalej korzystać z istniejącej bazy i tych samych haseł.

## Testy

```sh
./mvnw test          # jednostkowe, MVC i architektury, bez Dockera i połączenia z bazą
./mvnw clean verify  # dodatkowo testy integracyjne, wymaga działającego Dockera
```

W Windows użyj `.\mvnw.cmd`. Testcontainers automatycznie tworzy oddzielny PostgreSQL z losowymi poświadczeniami. Testy nie korzystają z lokalnych sekretów ani zewnętrznych adresów bazy. Brak działającego Dockera powoduje niepowodzenie etapu integracyjnego, zamiast pomijania testów.

Sprawdzane są: migracja V1 → V2 z zachowaniem starego przypisania, prawdziwe logowanie HTTP, renderowanie kalendarza, zapis wielu obszarów, zmiana i usunięcie przypisań, ustawienia nazw i kolorów, dezaktywacja bez utraty historii, walidacja, role, CSRF i trwałość po restarcie aplikacji. Wyniki XML znajdują się w `target/surefire-reports` i `target/failsafe-reports`.

## Struktura

```text
compose.yaml, pom.xml, mvnw, mvnw.cmd
docker/postgres/           inicjalizacja lokalnej bazy i konta aplikacji
scripts/                   inicjalizator sekretów i skrypty Windows
src/main/java/pl/nclean/crm/
  calendar/                kontroler, serwis, encje i repozytoria
  security/                logowanie i uprawnienia
  records/                 klienci, cennik, zlecenia, chemia
  dashboard/               koszty i podsumowania
  fuel/                    licznik, agregat, tankowania i zdjęcia
  work/                    dzień pracy, wykonanie, wpłaty i eksport
src/main/resources/
  application.yml, application-local.yml, application-prod.yml
  db/migration/V1__calendar.sql, V2__multiple_day_areas.sql
  templates/calendar/month.html
  templates/settings/areas.html
  static/css/, static/js/
src/test/java/pl/nclean/crm/calendar/
  CalendarSecurityTest.java
  CalendarPostgresIT.java
```

## Zakres

Początkowe obszary są przykładowymi strefami operacyjnymi; nazwa jest wyświetlana razem z kolorem. W ustawieniach można dodać własne obszary, edytować ich nazwy i kolory HEX oraz je dezaktywować. Dezaktywacja zachowuje istniejące przypisania; nieaktywny obszar można pozostawić przy danym dniu lub go odznaczyć, ale nie przypisywać do kolejnych dni. Zmiana nazwy lub koloru aktualizuje etykiety istniejących przypisań.

Przypisanie obszarów nie rezerwuje terminu. Zlecenia, kartoteka klientów i cennik są opisane w [docs/KLIENT-CENNIK.md](docs/KLIENT-CENNIK.md). Podsumowanie kosztów i przychodów opisano w [docs/DASHBOARD.md](docs/DASHBOARD.md). Nie ma SMS, księgowości, GPS ani inteligentnego dobierania terminów.

To lokalne środowisko deweloperskie. Publiczne wdrożenie, HTTPS, kopie zapasowe i konta użytkowników w bazie pozostają osobnymi zadaniami. Profil `prod` nie jest kompletną konfiguracją wdrożenia. Dokumenty historyczne: [audyt CMS](AUDYT-NcleanCMS.md) i [plan CRM](PLAN-CRM.md).

Interfejs i obsługa: [UX — codzienna praca](docs/UX-LEAN.md).

Podsumowanie i zamknięcie dnia: [instrukcja obsługi i testy](docs/ZAMKNIECIE-DNIA.md).

Notatki, zadania i cele przypinane do dashboardu: [obsługa i weryfikacja](docs/NOTATKI-I-CELE.md).

Koszty i inwestycje, książeczka samochodu i historia sprzętu: [obsługa, zasady rozliczeń i testy](docs/KOSZTY-I-INWESTYCJE.md).

Diagnoza wersji, naprawy formularzy i pełna weryfikacja: [docs/DIAGNOZA-I-NAPRAWY.md](docs/DIAGNOZA-I-NAPRAWY.md).

Pomoc kontekstową i krótkie samouczki obsługuje **ncLEANEK**. Grafika pozostaje wspólna dla całej aplikacji. [Obsługa pomocnika i wyniki testów](docs/NCLEANEK.md). Starsze audyty opisują historyczne nazewnictwo.

Prompt zastosowanego audytu motywu: [PIXEL-TYCOON-AUDIT-PROMPT.md](docs/PIXEL-TYCOON-AUDIT-PROMPT.md).
